import React, { createContext, useContext, useEffect, useRef, useState } from 'react';

interface AudioContextType {
  playAmbient: (type: 'cabin' | 'rain' | 'lofi') => void;
  stopAmbient: () => void;
  setVolume: (volume: number) => void;
  isPlaying: boolean;
}

const AudioContext = createContext<AudioContextType | null>(null);

export function useAudio() {
  const context = useContext(AudioContext);
  if (!context) throw new Error('useAudio must be used within AudioProvider');
  return context;
}

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const fadeIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize Audio Context
  useEffect(() => {
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    gainNodeRef.current = audioContextRef.current.createGain();
    gainNodeRef.current.connect(audioContextRef.current.destination);
    gainNodeRef.current.gain.value = 0; // Start silent
    
    return () => {
      audioContextRef.current?.close();
    };
  }, []);

  const createNoiseBuffer = (type: 'brown' | 'pink') => {
    if (!audioContextRef.current) return null;
    
    const bufferSize = audioContextRef.current.sampleRate * 2; // 2 seconds buffer
    const buffer = audioContextRef.current.createBuffer(1, bufferSize, audioContextRef.current.sampleRate);
    const data = buffer.getChannelData(0);

    if (type === 'brown') {
      let lastOut = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5; // Compensate for gain loss
      }
    } else {
      // Pink noise approximation
      let b0, b1, b2, b3, b4, b5, b6;
      b0 = b1 = b2 = b3 = b4 = b5 = b6 = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        data[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        data[i] *= 0.11; // Compensate for gain
        b6 = white * 0.115926;
      }
    }
    return buffer;
  };

  const playAmbient = (type: 'cabin' | 'rain' | 'lofi') => {
    if (!audioContextRef.current || !gainNodeRef.current) return;

    // Resume context if suspended (browser policy)
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(err => console.error("Audio resume failed:", err));
    }

    // Stop existing sound
    if (sourceNodeRef.current) {
      sourceNodeRef.current.stop();
    }

    // Create new source
    const buffer = createNoiseBuffer(type === 'cabin' ? 'brown' : 'pink');
    if (!buffer) return;

    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.connect(gainNodeRef.current);
    source.start();
    sourceNodeRef.current = source;
    setIsPlaying(true);

    // Fade In
    fadeIn();
  };

  const stopAmbient = () => {
    fadeOut(() => {
      if (sourceNodeRef.current) {
        sourceNodeRef.current.stop();
        sourceNodeRef.current = null;
      }
      setIsPlaying(false);
    });
  };

  const fadeIn = () => {
    if (!gainNodeRef.current) return;
    const gain = gainNodeRef.current.gain;
    
    // Cancel any scheduled changes
    gain.cancelScheduledValues(audioContextRef.current!.currentTime);
    
    // Ramp to 0.5 over 3 seconds
    gain.setValueAtTime(gain.value, audioContextRef.current!.currentTime);
    gain.linearRampToValueAtTime(0.5, audioContextRef.current!.currentTime + 3);
  };

  const fadeOut = (callback?: () => void) => {
    if (!gainNodeRef.current) return;
    const gain = gainNodeRef.current.gain;

    gain.cancelScheduledValues(audioContextRef.current!.currentTime);
    gain.setValueAtTime(gain.value, audioContextRef.current!.currentTime);
    gain.linearRampToValueAtTime(0, audioContextRef.current!.currentTime + 2);

    setTimeout(() => {
      if (callback) callback();
    }, 2000);
  };

  const setVolume = (volume: number) => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = volume;
    }
  };

  return (
    <AudioContext.Provider value={{ playAmbient, stopAmbient, setVolume, isPlaying }}>
      {children}
    </AudioContext.Provider>
  );
}
