import { useState } from 'react';
import { Compass, Map as MapIcon, BookOpen, ShoppingBag, User, History, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export type TabName = 'Focus' | 'Map' | 'History' | 'Passport' | 'Market' | 'Account' | 'Social';
export type SidebarPosition = 'left' | 'right' | 'top' | 'bottom';

interface SidebarProps {
  activeTab: TabName;
  onTabChange: (tab: TabName) => void;
  position?: SidebarPosition;
}

export function Sidebar({ activeTab, onTabChange, position = 'left' }: SidebarProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { t } = useLanguage();
  const isHorizontal = position === 'top' || position === 'bottom';

  const navItems: { name: TabName; icon: any }[] = [
    { name: 'Focus', icon: Compass },
    { name: 'Map', icon: MapIcon },
    { name: 'Social', icon: Users },
    { name: 'History', icon: History },
    { name: 'Passport', icon: BookOpen },
    { name: 'Market', icon: ShoppingBag },
    { name: 'Account', icon: User },
  ];

  const containerClasses = isHorizontal
    ? `w-full bg-[#0a0f12]/90 backdrop-blur-xl border-white/5 flex flex-row items-center justify-between px-4 z-50 relative transition-all duration-300 ease-in-out ${isExpanded ? 'h-20' : 'h-16'} ${position === 'top' ? 'border-b' : 'border-t'}`
    : `h-full bg-[#0a0f12]/90 backdrop-blur-xl border-white/5 flex flex-col justify-between py-8 z-50 relative transition-all duration-300 ease-in-out ${isExpanded ? 'w-64 px-4' : 'w-20 px-2'} ${position === 'left' ? 'border-r' : 'border-l'}`;

  const innerClasses = isHorizontal
    ? "flex flex-row items-center w-full gap-4"
    : "flex flex-col gap-12";

  const navClasses = isHorizontal
    ? "flex flex-row gap-2 flex-1 justify-center overflow-x-auto no-scrollbar"
    : "flex flex-col gap-4";

  return (
    <div className={containerClasses}>
      <div className={innerClasses}>
        {/* Logo */}
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className={`flex items-center gap-3 transition-all duration-300 outline-none ${isHorizontal ? '' : (isExpanded ? 'px-2 justify-start w-full' : 'justify-center w-full')}`}
        >
          <div className="w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br from-teal-400 to-emerald-600 flex items-center justify-center shadow-[0_0_20px_rgba(45,212,191,0.3)] hover:scale-105 transition-transform cursor-pointer">
            <Compass className="w-6 h-6 text-white" />
          </div>
          <span 
            className={`text-xl font-bold tracking-widest text-white whitespace-nowrap overflow-hidden transition-all duration-300 ${
              isExpanded ? 'max-w-[150px] opacity-100' : 'max-w-0 opacity-0'
            }`}
          >
            COMPASS
          </span>
        </button>

        {/* Navigation */}
        <nav className={navClasses}>
          {navItems.map((item) => {
            const isActive = activeTab === item.name;
            const translatedName = t(`nav.${item.name.toLowerCase()}`);
            return (
              <button
                key={item.name}
                onClick={() => onTabChange(item.name)}
                title={!isExpanded ? translatedName : undefined}
                className={`flex items-center rounded-2xl transition-all duration-300 ${
                  isHorizontal 
                    ? `px-3 py-2 ${isExpanded ? 'gap-2' : 'justify-center'}` 
                    : `py-3 ${isExpanded ? 'px-4 gap-4' : 'justify-center px-0'}`
                } ${
                  isActive
                    ? 'bg-white/10 border border-white/20 text-teal-400 shadow-[0_0_15px_rgba(45,212,191,0.15)]'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className={`w-6 h-6 shrink-0 ${isActive ? 'text-teal-400' : ''}`} />
                <span 
                  className={`font-medium tracking-wide whitespace-nowrap overflow-hidden transition-all duration-300 text-left ${
                    isExpanded ? 'max-w-[120px] opacity-100' : 'max-w-0 opacity-0'
                  }`}
                >
                  {translatedName}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
