import { useEffect, useState } from 'react';
import { X, Clock, Map, Globe, Stamp } from 'lucide-react';

interface PassportStats {
  totalCountries: number;
  totalFocusHours: number;
  stamps: {
    countryCode: string;
    countryName: string;
    date: string;
  }[];
}

interface PassportData {
  username: string;
  passportData: {
    surname: string;
    givenNames: string;
    nationality: string;
    photo?: string;
  };
  stats: PassportStats;
}

interface PassportModalProps {
  targetUserId: number;
  currentUserId: number;
  onClose: () => void;
}

export function PassportModal({ targetUserId, currentUserId, onClose }: PassportModalProps) {
  const [data, setData] = useState<PassportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/passport/${targetUserId}`, {
          headers: {
            'x-user-id': currentUserId.toString()
          }
        });

        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to load passport');
        }

        const jsonData = await res.json();
        setData(jsonData);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [targetUserId, currentUserId]);

  if (!targetUserId) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl bg-[#1a1f24] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 rounded-full text-white/70 hover:text-white transition-colors z-10"
        >
          <X className="w-6 h-6" />
        </button>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center h-64 text-red-400 p-8 text-center">
            <p className="text-lg font-semibold mb-2">Access Denied</p>
            <p className="text-sm opacity-80">{error}</p>
          </div>
        ) : data ? (
          <div className="flex flex-col h-full">
            {/* Passport Header / ID Card Style */}
            <div className="bg-indigo-900/30 p-8 border-b border-white/10 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Globe className="w-64 h-64 text-white" />
              </div>
              
              <div className="flex items-start gap-6 relative z-10">
                <div className="w-24 h-24 rounded-xl bg-white/10 border-2 border-white/20 flex items-center justify-center overflow-hidden shrink-0">
                  {data.passportData.photo ? (
                    <img src={data.passportData.photo} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-3xl font-bold text-white/30">{data.passportData.givenNames[0]}</span>
                  )}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h2 className="text-2xl font-bold text-white font-mono tracking-wider uppercase">
                      {data.passportData.surname}, {data.passportData.givenNames}
                    </h2>
                    <span className="px-2 py-0.5 bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs rounded uppercase tracking-widest">
                      {data.passportData.nationality}
                    </span>
                  </div>
                  <p className="text-indigo-200/60 font-mono text-sm mb-6">ID: {data.username}</p>

                  <div className="flex gap-8">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                        <Clock className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wider">Focus Hours</p>
                        <p className="text-xl font-bold text-white">{data.stats.totalFocusHours}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-400">
                        <Map className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wider">Countries</p>
                        <p className="text-xl font-bold text-white">{data.stats.totalCountries}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Stamps Grid */}
            <div className="flex-1 overflow-y-auto p-8 bg-[#121518]">
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Stamp className="w-4 h-4" /> Visa Stamps
              </h3>
              
              {data.stats.stamps.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-white/5 rounded-2xl">
                  <p className="text-gray-500">No stamps collected yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {data.stats.stamps.map((stamp, idx) => (
                    <div key={idx} className="aspect-square bg-[#1a1f24] border border-white/10 rounded-xl p-4 flex flex-col items-center justify-center text-center group hover:border-indigo-500/50 transition-colors relative overflow-hidden">
                      <div className="absolute inset-0 bg-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      
                      {/* Stamp Visual */}
                      <div className="w-12 h-12 rounded-full border-2 border-indigo-400/30 flex items-center justify-center mb-3 text-indigo-400/50 group-hover:text-indigo-400 group-hover:border-indigo-400 transition-all transform group-hover:scale-110 -rotate-12">
                        <span className="font-mono font-bold text-lg">{stamp.countryCode}</span>
                      </div>
                      
                      <p className="text-sm font-medium text-white relative z-10">{stamp.countryName}</p>
                      <p className="text-xs text-gray-500 mt-1 relative z-10">{new Date(stamp.date).toLocaleDateString()}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
