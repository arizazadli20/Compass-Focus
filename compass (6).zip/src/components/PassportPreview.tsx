import { useEffect, useState } from 'react';
import { MapPin, Clock, Globe, UserPlus, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface PassportPreviewProps {
  userId: number;
  position: { x: number; y: number } | null;
  onClose: () => void;
  onAddFriend: (id: number) => void;
  isFriend: boolean;
  isPending: boolean;
}

interface PreviewData {
  username: string;
  stats: {
    totalCountries: number;
    totalFocusHours: number;
    recentStamps: Array<{
      countryCode: string;
      countryName: string;
      date: string;
    }>;
  };
  isFriend: boolean;
}

// Simple memory cache to avoid re-fetching
const previewCache = new Map<number, PreviewData>();

export function PassportPreview({ userId, position, onAddFriend, isFriend, isPending }: PassportPreviewProps) {
  const { t } = useLanguage();
  const [data, setData] = useState<PreviewData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;

    // Check cache first
    if (previewCache.has(userId)) {
      setData(previewCache.get(userId)!);
      setLoading(false);
      return;
    }

    setLoading(true);
    const controller = new AbortController();

    fetch(`/api/passport/preview/${userId}`, { signal: controller.signal })
      .then(res => res.json())
      .then(fetchedData => {
        previewCache.set(userId, fetchedData);
        setData(fetchedData);
      })
      .catch(err => {
        if (err.name !== 'AbortError') console.error(err);
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [userId]);

  if (!position) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9 }}
        style={{ 
          position: 'fixed', 
          [document.documentElement.dir === 'rtl' ? 'right' : 'left']: position.x + 20, 
          top: position.y - 100,
          zIndex: 100 
        }}
        className="w-72 bg-[#1a1f2e] border border-amber-500/30 rounded-xl shadow-2xl overflow-hidden pointer-events-auto"
      >
        {/* Header / ID Card Look */}
        <div className="bg-[#11141d] p-3 border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-amber-500/20 border border-amber-500/50 flex items-center justify-center">
              <Globe className="w-2.5 h-2.5 text-amber-500" />
            </div>
            <span className="text-xs font-mono text-amber-500/80 tracking-widest uppercase">{t('social.passportPreview')}</span>
          </div>
        </div>

        <div className="p-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
            </div>
          ) : data ? (
            <>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold text-lg">
                  {data.username[0].toUpperCase()}
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg leading-none">{data.username}</h3>
                  <p className="text-xs text-gray-400 mt-1">{t('social.digitalNomad')}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                  <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                    <Clock className="w-3 h-3" /> {t('social.hours')}
                  </div>
                  <div className="text-white font-mono font-bold">{data.stats.totalFocusHours}</div>
                </div>
                <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                  <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                    <MapPin className="w-3 h-3" /> {t('social.countries')}
                  </div>
                  <div className="text-white font-mono font-bold">{data.stats.totalCountries}</div>
                </div>
              </div>

              {/* Recent Stamps */}
              {data.stats.recentStamps.length > 0 && (
                <div className="mb-4">
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">{t('social.recentStamps')}</p>
                  <div className="flex gap-2">
                    {data.stats.recentStamps.map((stamp, i) => (
                      <div key={i} className="w-8 h-8 rounded-full bg-[#2a3040] border border-white/10 flex items-center justify-center text-[10px] text-gray-400" title={stamp.countryName}>
                        {stamp.countryCode}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button */}
              {!isFriend && !data.isFriend && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddFriend(userId);
                  }}
                  disabled={isPending}
                  className={`w-full py-2 border text-xs font-bold rounded uppercase tracking-wide flex items-center justify-center gap-2 transition-colors ${
                    isPending 
                      ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-500 cursor-not-allowed'
                      : 'bg-indigo-600/20 border-indigo-500/50 text-indigo-400 hover:bg-indigo-600/30 cursor-pointer'
                  }`}
                >
                  {isPending ? (
                    <>
                      <Clock className="w-3 h-3" /> {t('social.requestPending')}
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3 h-3" /> {t('social.addFriend')}
                    </>
                  )}
                </button>
              )}
            </>
          ) : (
            <p className="text-red-400 text-xs">Failed to load data</p>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
