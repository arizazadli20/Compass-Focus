import { Plane, Car, Footprints, Map, Globe } from 'lucide-react';
import { UserStats } from '../utils/stats';

interface MapStatsOverlayProps {
  stats: UserStats;
}

export function MapStatsOverlay({ stats }: MapStatsOverlayProps) {
  return (
    <div className="absolute top-8 left-24 z-20 bg-[#0a0f12]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-6 w-80 shadow-2xl animate-in slide-in-from-left duration-500">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-teal-500/20 flex items-center justify-center text-teal-400">
          <Map className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">Travel Stats</h2>
          <p className="text-xs text-gray-400">Your journey in numbers</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Countries Visited */}
        <div className="bg-white/5 rounded-xl p-4 border border-white/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400 text-sm">Countries Visited</span>
            <Globe className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-bold text-white">{stats.countriesVisited}</div>
        </div>

        {/* Total Distance */}
        <div className="bg-white/5 rounded-xl p-4 border border-white/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400 text-sm">Total Distance</span>
            <span className="text-xs text-teal-400 font-mono">KM</span>
          </div>
          <div className="text-3xl font-bold text-white">{stats.totalDistanceKm.toLocaleString()}</div>
        </div>

        {/* Transport Breakdown */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="bg-white/5 rounded-xl p-3 border border-white/5 text-center">
            <Plane className="w-5 h-5 text-sky-400 mx-auto mb-2" />
            <div className="text-lg font-bold text-white">{stats.hoursPlane}h</div>
            <div className="text-[10px] text-gray-500 uppercase tracking-wider">Air</div>
          </div>
          
          <div className="bg-white/5 rounded-xl p-3 border border-white/5 text-center">
            <Car className="w-5 h-5 text-rose-400 mx-auto mb-2" />
            <div className="text-lg font-bold text-white">{stats.hoursCar}h</div>
            <div className="text-[10px] text-gray-500 uppercase tracking-wider">Road</div>
          </div>
          
          <div className="bg-white/5 rounded-xl p-3 border border-white/5 text-center">
            <Footprints className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
            <div className="text-lg font-bold text-white">{stats.hoursWalked}h</div>
            <div className="text-[10px] text-gray-500 uppercase tracking-wider">Walk</div>
          </div>
        </div>
      </div>
    </div>
  );
}
