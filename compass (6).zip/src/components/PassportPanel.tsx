import React, { useState, useEffect, useRef } from 'react';
import { User, Plane, Globe, ChevronLeft, ChevronRight, Shield, Check, Edit2, Save, Upload, X } from 'lucide-react';
import { TravelHistoryItem } from './TravelHistoryPanel';
import { useLanguage } from '../contexts/LanguageContext';

interface PassportData {
  surname: string;
  givenNames: string;
  nationality: string;
  dob: string;
  sex: string;
  pob: string;
  photo: string;
}

interface PassportPanelProps {
  ownedVisas: string[];
  travelHistory: TravelHistoryItem[];
  passportData: PassportData;
  onUpdatePassport: (data: PassportData) => void;
}

export function PassportPanel({ ownedVisas, travelHistory, passportData, onUpdatePassport }: PassportPanelProps) {
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0); // 0: Info/Visas, 1: Stamps 1/2
  const [isFading, setIsFading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showCountrySelector, setShowCountrySelector] = useState(false);
  const [editData, setEditData] = useState<PassportData>(passportData);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const COUNTRIES = [
    { code: 'EARTH', name: 'Earth', flag: '🌍' },
    { code: 'AF', name: 'Afghanistan', flag: '🇦🇫' },
    { code: 'AL', name: 'Albania', flag: '🇦🇱' },
    { code: 'DZ', name: 'Algeria', flag: '🇩🇿' },
    { code: 'AD', name: 'Andorra', flag: '🇦🇩' },
    { code: 'AO', name: 'Angola', flag: '🇦🇴' },
    { code: 'AG', name: 'Antigua and Barbuda', flag: '🇦🇬' },
    { code: 'AR', name: 'Argentina', flag: '🇦🇷' },
    { code: 'AM', name: 'Armenia', flag: '🇦🇲' },
    { code: 'AU', name: 'Australia', flag: '🇦🇺' },
    { code: 'AT', name: 'Austria', flag: '🇦🇹' },
    { code: 'AZ', name: 'Azerbaijan', flag: '🇦🇿' },
    { code: 'BS', name: 'Bahamas', flag: '🇧🇸' },
    { code: 'BH', name: 'Bahrain', flag: '🇧🇭' },
    { code: 'BD', name: 'Bangladesh', flag: '🇧🇩' },
    { code: 'BB', name: 'Barbados', flag: '🇧🇧' },
    { code: 'BY', name: 'Belarus', flag: '🇧🇾' },
    { code: 'BE', name: 'Belgium', flag: '🇧🇪' },
    { code: 'BZ', name: 'Belize', flag: '🇧🇿' },
    { code: 'BJ', name: 'Benin', flag: '🇧🇯' },
    { code: 'BT', name: 'Bhutan', flag: '🇧🇹' },
    { code: 'BO', name: 'Bolivia', flag: '🇧🇴' },
    { code: 'BA', name: 'Bosnia and Herzegovina', flag: '🇧🇦' },
    { code: 'BW', name: 'Botswana', flag: '🇧🇼' },
    { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
    { code: 'BN', name: 'Brunei', flag: '🇧🇳' },
    { code: 'BG', name: 'Bulgaria', flag: '🇧🇬' },
    { code: 'BF', name: 'Burkina Faso', flag: '🇧🇫' },
    { code: 'BI', name: 'Burundi', flag: '🇧🇮' },
    { code: 'CV', name: 'Cabo Verde', flag: '🇨🇻' },
    { code: 'KH', name: 'Cambodia', flag: '🇰🇭' },
    { code: 'CM', name: 'Cameroon', flag: '🇨🇲' },
    { code: 'CA', name: 'Canada', flag: '🇨🇦' },
    { code: 'CF', name: 'Central African Republic', flag: '🇨🇫' },
    { code: 'TD', name: 'Chad', flag: '🇹🇩' },
    { code: 'CL', name: 'Chile', flag: '🇨🇱' },
    { code: 'CN', name: 'China', flag: '🇨🇳' },
    { code: 'CO', name: 'Colombia', flag: '🇨🇴' },
    { code: 'KM', name: 'Comoros', flag: '🇰🇲' },
    { code: 'CG', name: 'Congo', flag: '🇨🇬' },
    { code: 'CD', name: 'Congo (DRC)', flag: '🇨🇩' },
    { code: 'CR', name: 'Costa Rica', flag: '🇨🇷' },
    { code: 'HR', name: 'Croatia', flag: '🇭🇷' },
    { code: 'CU', name: 'Cuba', flag: '🇨🇺' },
    { code: 'CY', name: 'Cyprus', flag: '🇨🇾' },
    { code: 'CZ', name: 'Czech Republic', flag: '🇨🇿' },
    { code: 'DK', name: 'Denmark', flag: '🇩🇰' },
    { code: 'DJ', name: 'Djibouti', flag: '🇩🇯' },
    { code: 'DM', name: 'Dominica', flag: '🇩🇲' },
    { code: 'DO', name: 'Dominican Republic', flag: '🇩🇴' },
    { code: 'EC', name: 'Ecuador', flag: '🇪🇨' },
    { code: 'EG', name: 'Egypt', flag: '🇪🇬' },
    { code: 'SV', name: 'El Salvador', flag: '🇸🇻' },
    { code: 'GQ', name: 'Equatorial Guinea', flag: '🇬🇶' },
    { code: 'ER', name: 'Eritrea', flag: '🇪🇷' },
    { code: 'EE', name: 'Estonia', flag: '🇪🇪' },
    { code: 'SZ', name: 'Eswatini', flag: '🇸🇿' },
    { code: 'ET', name: 'Ethiopia', flag: '🇪🇹' },
    { code: 'FJ', name: 'Fiji', flag: '🇫🇯' },
    { code: 'FI', name: 'Finland', flag: '🇫🇮' },
    { code: 'FR', name: 'France', flag: '🇫🇷' },
    { code: 'GA', name: 'Gabon', flag: '🇬🇦' },
    { code: 'GM', name: 'Gambia', flag: '🇬🇲' },
    { code: 'GE', name: 'Georgia', flag: '🇬🇪' },
    { code: 'DE', name: 'Germany', flag: '🇩🇪' },
    { code: 'GH', name: 'Ghana', flag: '🇬🇭' },
    { code: 'GR', name: 'Greece', flag: '🇬🇷' },
    { code: 'GD', name: 'Grenada', flag: '🇬🇩' },
    { code: 'GT', name: 'Guatemala', flag: '🇬🇹' },
    { code: 'GN', name: 'Guinea', flag: '🇬🇳' },
    { code: 'GW', name: 'Guinea-Bissau', flag: '🇬🇼' },
    { code: 'GY', name: 'Guyana', flag: '🇬🇾' },
    { code: 'HT', name: 'Haiti', flag: '🇭🇹' },
    { code: 'HN', name: 'Honduras', flag: '🇭🇳' },
    { code: 'HU', name: 'Hungary', flag: '🇭🇺' },
    { code: 'IS', name: 'Iceland', flag: '🇮🇸' },
    { code: 'IN', name: 'India', flag: '🇮🇳' },
    { code: 'ID', name: 'Indonesia', flag: '🇮🇩' },
    { code: 'IR', name: 'Iran', flag: '🇮🇷' },
    { code: 'IQ', name: 'Iraq', flag: '🇮🇶' },
    { code: 'IE', name: 'Ireland', flag: '🇮🇪' },
    { code: 'IL', name: 'Israel', flag: '🇮🇱' },
    { code: 'IT', name: 'Italy', flag: '🇮🇹' },
    { code: 'JM', name: 'Jamaica', flag: '🇯🇲' },
    { code: 'JP', name: 'Japan', flag: '🇯🇵' },
    { code: 'JO', name: 'Jordan', flag: '🇯🇴' },
    { code: 'KZ', name: 'Kazakhstan', flag: '🇰🇿' },
    { code: 'KE', name: 'Kenya', flag: '🇰🇪' },
    { code: 'KI', name: 'Kiribati', flag: '🇰🇮' },
    { code: 'KP', name: 'North Korea', flag: '🇰🇵' },
    { code: 'KR', name: 'South Korea', flag: '🇰🇷' },
    { code: 'KW', name: 'Kuwait', flag: '🇰🇼' },
    { code: 'KG', name: 'Kyrgyzstan', flag: '🇰🇬' },
    { code: 'LA', name: 'Laos', flag: '🇱🇦' },
    { code: 'LV', name: 'Latvia', flag: '🇱🇻' },
    { code: 'LB', name: 'Lebanon', flag: '🇱🇧' },
    { code: 'LS', name: 'Lesotho', flag: '🇱🇸' },
    { code: 'LR', name: 'Liberia', flag: '🇱🇷' },
    { code: 'LY', name: 'Libya', flag: '🇱🇾' },
    { code: 'LI', name: 'Liechtenstein', flag: '🇱🇮' },
    { code: 'LT', name: 'Lithuania', flag: '🇱🇹' },
    { code: 'LU', name: 'Luxembourg', flag: '🇱🇺' },
    { code: 'MG', name: 'Madagascar', flag: '🇲🇬' },
    { code: 'MW', name: 'Malawi', flag: '🇲🇼' },
    { code: 'MY', name: 'Malaysia', flag: '🇲🇾' },
    { code: 'MV', name: 'Maldives', flag: '🇲🇻' },
    { code: 'ML', name: 'Mali', flag: '🇲🇱' },
    { code: 'MT', name: 'Malta', flag: '🇲🇹' },
    { code: 'MH', name: 'Marshall Islands', flag: '🇲🇭' },
    { code: 'MR', name: 'Mauritania', flag: '🇲🇷' },
    { code: 'MU', name: 'Mauritius', flag: '🇲🇺' },
    { code: 'MX', name: 'Mexico', flag: '🇲🇽' },
    { code: 'FM', name: 'Micronesia', flag: '🇫🇲' },
    { code: 'MD', name: 'Moldova', flag: '🇲🇩' },
    { code: 'MC', name: 'Monaco', flag: '🇲🇨' },
    { code: 'MN', name: 'Mongolia', flag: '🇲🇳' },
    { code: 'ME', name: 'Montenegro', flag: '🇲🇪' },
    { code: 'MA', name: 'Morocco', flag: '🇲🇦' },
    { code: 'MZ', name: 'Mozambique', flag: '🇲🇿' },
    { code: 'MM', name: 'Myanmar', flag: '🇲🇲' },
    { code: 'NA', name: 'Namibia', flag: '🇳🇦' },
    { code: 'NR', name: 'Nauru', flag: '🇳🇷' },
    { code: 'NP', name: 'Nepal', flag: '🇳🇵' },
    { code: 'NL', name: 'Netherlands', flag: '🇳🇱' },
    { code: 'NZ', name: 'New Zealand', flag: '🇳🇿' },
    { code: 'NI', name: 'Nicaragua', flag: '🇳🇮' },
    { code: 'NE', name: 'Niger', flag: '🇳🇪' },
    { code: 'NG', name: 'Nigeria', flag: '🇳🇬' },
    { code: 'MK', name: 'North Macedonia', flag: '🇲🇰' },
    { code: 'NO', name: 'Norway', flag: '🇳🇴' },
    { code: 'OM', name: 'Oman', flag: '🇴🇲' },
    { code: 'PK', name: 'Pakistan', flag: '🇵🇰' },
    { code: 'PW', name: 'Palau', flag: '🇵🇼' },
    { code: 'PA', name: 'Panama', flag: '🇵🇦' },
    { code: 'PG', name: 'Papua New Guinea', flag: '🇵🇬' },
    { code: 'PY', name: 'Paraguay', flag: '🇵🇾' },
    { code: 'PE', name: 'Peru', flag: '🇵🇪' },
    { code: 'PH', name: 'Philippines', flag: '🇵🇭' },
    { code: 'PL', name: 'Poland', flag: '🇵🇱' },
    { code: 'PT', name: 'Portugal', flag: '🇵🇹' },
    { code: 'QA', name: 'Qatar', flag: '🇶🇦' },
    { code: 'RO', name: 'Romania', flag: '🇷🇴' },
    { code: 'RU', name: 'Russia', flag: '🇷🇺' },
    { code: 'RW', name: 'Rwanda', flag: '🇷🇼' },
    { code: 'KN', name: 'Saint Kitts and Nevis', flag: '🇰🇳' },
    { code: 'LC', name: 'Saint Lucia', flag: '🇱🇨' },
    { code: 'VC', name: 'Saint Vincent and the Grenadines', flag: '🇻🇨' },
    { code: 'WS', name: 'Samoa', flag: '🇼🇸' },
    { code: 'SM', name: 'San Marino', flag: '🇸🇲' },
    { code: 'ST', name: 'Sao Tome and Principe', flag: '🇸🇹' },
    { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦' },
    { code: 'SN', name: 'Senegal', flag: '🇸🇳' },
    { code: 'RS', name: 'Serbia', flag: '🇷🇸' },
    { code: 'SC', name: 'Seychelles', flag: '🇸🇨' },
    { code: 'SL', name: 'Sierra Leone', flag: '🇸🇱' },
    { code: 'SG', name: 'Singapore', flag: '🇸🇬' },
    { code: 'SK', name: 'Slovakia', flag: '🇸🇰' },
    { code: 'SI', name: 'Slovenia', flag: '🇸🇮' },
    { code: 'SB', name: 'Solomon Islands', flag: '🇸🇧' },
    { code: 'SO', name: 'Somalia', flag: '🇸🇴' },
    { code: 'ZA', name: 'South Africa', flag: '🇿🇦' },
    { code: 'SS', name: 'South Sudan', flag: '🇸🇸' },
    { code: 'ES', name: 'Spain', flag: '🇪🇸' },
    { code: 'LK', name: 'Sri Lanka', flag: '🇱🇰' },
    { code: 'SD', name: 'Sudan', flag: '🇸🇩' },
    { code: 'SR', name: 'Suriname', flag: '🇸🇷' },
    { code: 'SE', name: 'Sweden', flag: '🇸🇪' },
    { code: 'CH', name: 'Switzerland', flag: '🇨🇭' },
    { code: 'SY', name: 'Syria', flag: '🇸🇾' },
    { code: 'TW', name: 'Taiwan', flag: '🇹🇼' },
    { code: 'TJ', name: 'Tajikistan', flag: '🇹🇯' },
    { code: 'TZ', name: 'Tanzania', flag: '🇹🇿' },
    { code: 'TH', name: 'Thailand', flag: '🇹🇭' },
    { code: 'TL', name: 'Timor-Leste', flag: '🇹🇱' },
    { code: 'TG', name: 'Togo', flag: '🇹🇬' },
    { code: 'TO', name: 'Tonga', flag: '🇹🇴' },
    { code: 'TT', name: 'Trinidad and Tobago', flag: '🇹🇹' },
    { code: 'TN', name: 'Tunisia', flag: '🇹🇳' },
    { code: 'TR', name: 'Turkey', flag: '🇹🇷' },
    { code: 'TM', name: 'Turkmenistan', flag: '🇹🇲' },
    { code: 'TV', name: 'Tuvalu', flag: '🇹🇻' },
    { code: 'UG', name: 'Uganda', flag: '🇺🇬' },
    { code: 'UA', name: 'Ukraine', flag: '🇺🇦' },
    { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪' },
    { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
    { code: 'US', name: 'United States', flag: '🇺🇸' },
    { code: 'UY', name: 'Uruguay', flag: '🇺🇾' },
    { code: 'UZ', name: 'Uzbekistan', flag: '🇺🇿' },
    { code: 'VU', name: 'Vanuatu', flag: '🇻🇺' },
    { code: 'VA', name: 'Vatican City', flag: '🇻🇦' },
    { code: 'VE', name: 'Venezuela', flag: '🇻🇪' },
    { code: 'VN', name: 'Vietnam', flag: '🇻🇳' },
    { code: 'YE', name: 'Yemen', flag: '🇾🇪' },
    { code: 'ZM', name: 'Zambia', flag: '🇿🇲' },
    { code: 'ZW', name: 'Zimbabwe', flag: '🇿🇼' },
  ];

  useEffect(() => {
    setEditData(passportData);
  }, [passportData]);

  const handleSave = () => {
    onUpdatePassport(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData(passportData);
    setIsEditing(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    // Open the book shortly after mounting
    const timer = setTimeout(() => setIsOpen(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Reset to page 0 after the book closes
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (!isOpen) {
      timeout = setTimeout(() => {
        setCurrentPage(0);
      }, 1000);
    }
    return () => clearTimeout(timeout);
  }, [isOpen]);

  const changePage = (newPage: number) => {
    setIsFading(true);
    setTimeout(() => {
      setCurrentPage(newPage);
      setIsFading(false);
    }, 200);
  };

  const handleNextPage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOpen) {
      setIsOpen(true);
      return;
    }
    if (currentPage < 1) {
      changePage(currentPage + 1);
    } else {
      setIsOpen(false);
    }
  };

  const handlePrevPage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOpen) return;
    if (currentPage > 0) {
      changePage(currentPage - 1);
    } else {
      setIsOpen(false);
    }
  };

  // Process travel history into stamps
  const stamps = travelHistory.map((trip, i) => {
    const colors = [
      'border-red-600 text-red-600',
      'border-blue-600 text-blue-600',
      'border-indigo-600 text-indigo-600',
      'border-emerald-600 text-emerald-600',
      'border-purple-600 text-purple-600',
      'border-orange-600 text-orange-600',
    ];
    const angles = ['-rotate-12', 'rotate-6', '-rotate-6', 'rotate-12', '-rotate-3', 'rotate-3'];
    
    return {
      city: trip.city,
      country: trip.country.substring(0, 3).toUpperCase(),
      date: new Date(trip.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase(),
      color: colors[i % colors.length],
      angle: angles[i % angles.length],
      type: 'entry'
    };
  });

  const stampsPage1 = stamps.slice(0, 6);
  const stampsPage2 = stamps.slice(6, 12);

  const visaDetails: Record<string, { name: string, color: string, flag: string }> = {
    'Schengen': { name: 'Schengen Area', color: 'from-blue-500 to-indigo-600', flag: '🇪🇺' },
    'JPN': { name: 'Japan', color: 'from-red-500 to-rose-600', flag: '🇯🇵' },
    'USA': { name: 'United States', color: 'from-blue-600 to-red-600', flag: '🇺🇸' },
    'AUS': { name: 'Australia', color: 'from-emerald-500 to-teal-600', flag: '🇦🇺' },
    'MARS': { name: 'Mars Colony', color: 'from-orange-500 to-red-600', flag: '🪐' },
    'GLOBAL': { name: 'Global Citizen', color: 'from-purple-500 to-fuchsia-600', flag: '🌍' },
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center pointer-events-none bg-[#0a0f12]/40 backdrop-blur-sm">
      
      {/* Pagination Controls */}
      <div className={`absolute bottom-12 flex gap-4 pointer-events-auto z-50 transition-all duration-500 ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
        <button 
          onClick={handlePrevPage}
          className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all shadow-lg"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="h-12 px-6 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white font-mono font-bold tracking-widest shadow-lg">
          {currentPage === 0 ? '1 - 2' : '3 - 4'} / 4
        </div>
        <button 
          onClick={handleNextPage}
          className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all shadow-lg"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="perspective-[2000px] pointer-events-auto">
        {/* Book Wrapper */}
        <div 
          className="relative w-[300px] md:w-[350px] h-[450px] md:h-[500px] transition-transform duration-1000 ease-[cubic-bezier(0.34,1.56,0.64,1)]"
          style={{
            transform: isOpen ? 'translateX(150px)' : 'translateX(0)',
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Right Side (Back Cover + Right Page) */}
          <div 
            className="absolute inset-0 bg-[#1a2b4c] rounded-r-2xl shadow-[20px_20px_40px_rgba(0,0,0,0.6)] border-l border-black/40 cursor-pointer"
            style={{ transformStyle: 'preserve-3d' }}
            onClick={handleNextPage}
          >
            {/* Right Page (Inside) */}
            <div 
              className="absolute inset-y-1 right-1 left-0 bg-[#fdfbf7] rounded-r-xl p-5 overflow-hidden shadow-inner"
              style={{ transform: 'translateZ(1px)' }}
            >
              {/* Background Watermark */}
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                <div className="w-48 h-48 rounded-full border-[16px] border-slate-900"></div>
              </div>

              <div className={`relative z-10 h-full flex flex-col transition-opacity duration-200 ${isFading ? 'opacity-0' : 'opacity-100'}`}>
                {currentPage === 0 ? (
                  // PAGE 2: VISAS
                  <>
                    <div className="flex justify-between items-end border-b-2 border-slate-800 pb-1 mb-4">
                      <h2 className="text-lg font-bold text-slate-800 tracking-widest uppercase">{t('passport.visas')}</h2>
                      <span className="text-slate-500 font-mono text-xs">PAGE 2</span>
                    </div>

                    <div className="flex flex-col gap-3 overflow-y-auto h-[380px] pr-1 custom-scrollbar">
                      {ownedVisas.length === 0 ? (
                        <div className="text-center text-slate-400 mt-10 text-sm font-medium">{t('passport.noVisas')}</div>
                      ) : (
                        ownedVisas.map((visaId) => {
                          const details = visaDetails[visaId] || { name: visaId, color: 'from-gray-500 to-slate-600', flag: '❓' };
                          return (
                            <div key={visaId} className="relative overflow-hidden rounded-xl border border-slate-300 p-3 shadow-sm bg-white">
                              <div className={`absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b ${details.color}`}></div>
                              <div className="flex items-center gap-3 pl-2">
                                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${details.color} flex items-center justify-center text-white shadow-sm text-lg`}>
                                  {details.flag}
                                </div>
                                <div className="flex-1">
                                  <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide">{details.name}</h3>
                                  <p className="text-[9px] text-slate-500 font-mono">ID: {visaId}</p>
                                </div>
                                <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center border border-emerald-200">
                                  <Check className="w-3 h-3 text-emerald-600" />
                                </div>
                              </div>
                              {/* Watermark on visa */}
                              <div className="absolute -right-4 -bottom-4 opacity-5 pointer-events-none">
                                <Shield className="w-16 h-16 text-slate-900" />
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </>
                ) : (
                  // PAGE 4: STAMPS 2
                  <>
                    <div className="flex justify-between items-end border-b-2 border-slate-800 pb-1 mb-4">
                      <h2 className="text-lg font-bold text-slate-800 tracking-widest uppercase">{t('passport.stamps')}</h2>
                      <span className="text-slate-500 font-mono text-xs">PAGE 4</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {stampsPage2.map((stamp, index) => (
                        <div key={index} className={`flex justify-center items-center ${stamp.angle} opacity-80 hover:opacity-100 transition-opacity`}>
                          <div className={`w-24 h-24 rounded-full border-[3px] ${stamp.color} flex flex-col items-center justify-center relative p-1`}>
                            <div className={`absolute inset-1 rounded-full border border-dashed ${stamp.color} opacity-50`}></div>
                            <span className="text-[8px] font-bold tracking-widest uppercase mb-0.5">{stamp.country}</span>
                            <span className="text-[11px] font-black tracking-wider uppercase text-center leading-tight mb-0.5">{stamp.city}</span>
                            <div className="flex items-center gap-1 mb-0.5">
                              <div className={`w-0.5 h-0.5 rounded-full bg-current`}></div>
                              <Plane className="w-3 h-3" />
                              <div className={`w-0.5 h-0.5 rounded-full bg-current`}></div>
                            </div>
                            <span className="text-[7px] font-bold font-mono">{stamp.date}</span>
                            <div className={`absolute -bottom-2 bg-[#fdfbf7] px-2 text-[8px] font-black uppercase tracking-widest ${stamp.color}`}>
                              {stamp.type}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Left Side (Front Cover + Left Page) */}
          <div 
            className="absolute inset-0 origin-left transition-transform duration-1000 ease-[cubic-bezier(0.34,1.56,0.64,1)] cursor-pointer"
            style={{
              transform: isOpen ? 'rotateY(-180deg)' : 'rotateY(0deg)',
              transformStyle: 'preserve-3d',
            }}
            onClick={(e) => {
              if (!isOpen) {
                e.stopPropagation();
                setIsOpen(true);
              } else {
                handlePrevPage(e);
              }
            }}
          >
            {/* Front Cover (Outside) */}
            <div 
              className="absolute inset-0 bg-[#1a2b4c] rounded-r-2xl border-l border-white/10 flex flex-col items-center justify-center p-6 shadow-[-20px_20px_40px_rgba(0,0,0,0.6)]"
              style={{ 
                transform: 'translateZ(1px)',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden'
              }}
            >
              <Globe className="w-20 h-20 text-yellow-600/80 mb-8" />
              <h1 className="text-3xl font-serif text-yellow-600/90 tracking-[0.3em] uppercase text-center">{t('passport.title')}</h1>
              <div className="w-16 h-[1px] bg-yellow-600/50 my-8"></div>
              <p className="text-yellow-600/70 tracking-widest uppercase text-sm">{t('passport.earthUnion')}</p>
            </div>

            {/* Left Page (Inside of Front Cover) */}
            <div 
              className="absolute inset-y-1 left-1 right-0 bg-[#fdfbf7] rounded-l-xl p-5 overflow-hidden shadow-inner"
              style={{ 
                transform: 'rotateY(180deg) translateZ(1px)',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden'
              }}
            >
              {/* Background Watermark */}
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                <Plane className="w-48 h-48" />
              </div>

              <div className={`relative z-10 h-full flex flex-col transition-opacity duration-200 ${isFading ? 'opacity-0' : 'opacity-100'}`}>
                {currentPage === 0 ? (
                  // PAGE 1: INFORMATION
                  <>
                    <div className="flex justify-between items-end border-b-2 border-slate-800 pb-1 mb-4">
                      <h2 className="text-lg font-bold text-slate-800 tracking-widest uppercase">{t('passport.title')}</h2>
                      <div className="flex items-center gap-2">
                        {isEditing ? (
                          <>
                            <button onClick={(e) => { e.stopPropagation(); handleSave(); }} className="p-1 hover:bg-green-100 rounded text-green-600 transition-colors" title="Save">
                              <Save className="w-4 h-4" />
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); handleCancel(); }} className="p-1 hover:bg-red-100 rounded text-red-600 transition-colors" title="Cancel">
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        ) : (
                          <button onClick={(e) => { e.stopPropagation(); setIsEditing(true); }} className="p-1 hover:bg-slate-200 rounded text-slate-500 transition-colors" title="Edit Details">
                            <Edit2 className="w-3 h-3" />
                          </button>
                        )}
                        <span className="text-slate-500 font-mono text-xs">PAGE 1</span>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      {/* Photo Placeholder */}
                      <div className="relative group" onClick={(e) => e.stopPropagation()}>
                        <div className="w-24 h-32 border-2 border-slate-300 bg-slate-100 rounded flex items-center justify-center shadow-inner overflow-hidden flex-shrink-0 relative">
                          {editData.photo ? (
                            <img src={editData.photo} alt="Passport" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <>
                              <div className="absolute inset-0 opacity-20 bg-[repeating-linear-gradient(45deg,transparent,transparent_2px,#000_2px,#000_4px)]"></div>
                              <User className="w-14 h-14 text-slate-400 relative z-10" />
                            </>
                          )}
                        </div>
                        
                        {isEditing && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                            className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded cursor-pointer"
                          >
                            <Upload className="w-6 h-6 text-white" />
                          </button>
                        )}
                        <input 
                          type="file" 
                          ref={fileInputRef} 
                          className="hidden" 
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>

                      {/* Details Grid */}
                      <div className="flex-1 grid grid-cols-2 gap-x-2 gap-y-3 relative">
                        {/* Country Selector Modal */}
                        {showCountrySelector && (
                          <div 
                            className="absolute inset-0 z-50 bg-white border border-slate-300 rounded shadow-lg overflow-y-auto"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <div className="sticky top-0 bg-slate-100 p-2 border-b border-slate-200 flex justify-between items-center">
                              <span className="text-xs font-bold text-slate-700 uppercase">Select Country</span>
                              <button onClick={(e) => { e.stopPropagation(); setShowCountrySelector(false); }}>
                                <X className="w-4 h-4 text-slate-500" />
                              </button>
                            </div>
                            {COUNTRIES.map((c) => (
                              <button
                                key={c.code}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 border-b border-slate-100 flex items-center gap-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditData({ ...editData, nationality: c.name });
                                  setShowCountrySelector(false);
                                }}
                              >
                                <span className="text-lg">{c.flag}</span>
                                <span className="text-xs font-bold text-slate-800 uppercase">{c.name}</span>
                              </button>
                            ))}
                          </div>
                        )}

                        <div className="col-span-2">
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.surname')}</p>
                          {isEditing ? (
                            <input 
                              type="text" 
                              value={editData.surname} 
                              onChange={(e) => setEditData({...editData, surname: e.target.value})}
                              onClick={(e) => e.stopPropagation()}
                              className="w-full text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-1"
                            />
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.surname}</p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.givenNames')}</p>
                          {isEditing ? (
                            <input 
                              type="text" 
                              value={editData.givenNames} 
                              onChange={(e) => setEditData({...editData, givenNames: e.target.value})}
                              onClick={(e) => e.stopPropagation()}
                              className="w-full text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-1"
                            />
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.givenNames}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.nationality')}</p>
                          {isEditing ? (
                            <button 
                              onClick={(e) => { e.stopPropagation(); setShowCountrySelector(true); }}
                              className="w-full text-left text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-1 flex items-center justify-between"
                            >
                              <span className="truncate">{editData.nationality}</span>
                              <span className="text-[10px] opacity-50">▼</span>
                            </button>
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.nationality}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.dob')}</p>
                          {isEditing ? (
                            <input 
                              type="text" 
                              value={editData.dob} 
                              onChange={(e) => setEditData({...editData, dob: e.target.value})}
                              onClick={(e) => e.stopPropagation()}
                              className="w-full text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-1"
                              placeholder="DD MMM YYYY"
                            />
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.dob}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.sex')}</p>
                          {isEditing ? (
                            <select 
                              value={editData.sex} 
                              onChange={(e) => setEditData({...editData, sex: e.target.value})}
                              onClick={(e) => e.stopPropagation()}
                              className="w-full text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-0"
                            >
                              <option value="M">M</option>
                              <option value="F">F</option>
                              <option value="X">X</option>
                              <option value="U">U</option>
                            </select>
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.sex}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.pob')}</p>
                          {isEditing ? (
                            <input 
                              type="text" 
                              value={editData.pob} 
                              onChange={(e) => setEditData({...editData, pob: e.target.value})}
                              onClick={(e) => e.stopPropagation()}
                              className="w-full text-xs font-bold text-slate-900 uppercase bg-slate-100 border-b border-slate-300 focus:outline-none focus:border-blue-500 px-1"
                            />
                          ) : (
                            <p className="text-xs font-bold text-slate-900 uppercase">{passportData.pob}</p>
                          )}
                        </div>
                        <div className="col-span-2">
                          <p className="text-[8px] text-slate-500 uppercase font-bold">{t('passport.authority')}</p>
                          <p className="text-xs font-bold text-slate-900 uppercase">Compass App</p>
                        </div>
                      </div>
                    </div>

                    {/* Machine Readable Zone (MRZ) */}
                    <div className="mt-auto pt-4 border-t border-slate-200">
                      <p className="font-mono text-[9px] md:text-[10px] text-slate-800 tracking-[0.1em] leading-relaxed font-bold opacity-80 break-all">
                        P&lt;ERT{(isEditing ? editData : passportData).surname.toUpperCase().replace(/ /g, '<')}&lt;&lt;{(isEditing ? editData : passportData).givenNames.toUpperCase().replace(/ /g, '<')}&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;<br/>
                        A123456789ERT9001014{(isEditing ? editData : passportData).sex}2401019&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;06
                      </p>
                    </div>
                  </>
                ) : (
                  // PAGE 3: STAMPS 1
                  <>
                    <div className="flex justify-between items-end border-b-2 border-slate-800 pb-1 mb-4">
                      <h2 className="text-lg font-bold text-slate-800 tracking-widest uppercase">{t('passport.stamps')}</h2>
                      <span className="text-slate-500 font-mono text-xs">PAGE 3</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {stampsPage1.map((stamp, index) => (
                        <div key={index} className={`flex justify-center items-center ${stamp.angle} opacity-80 hover:opacity-100 transition-opacity`}>
                          <div className={`w-24 h-24 rounded-full border-[3px] ${stamp.color} flex flex-col items-center justify-center relative p-1`}>
                            <div className={`absolute inset-1 rounded-full border border-dashed ${stamp.color} opacity-50`}></div>
                            <span className="text-[8px] font-bold tracking-widest uppercase mb-0.5">{stamp.country}</span>
                            <span className="text-[11px] font-black tracking-wider uppercase text-center leading-tight mb-0.5">{stamp.city}</span>
                            <div className="flex items-center gap-1 mb-0.5">
                              <div className={`w-0.5 h-0.5 rounded-full bg-current`}></div>
                              <Plane className="w-3 h-3" />
                              <div className={`w-0.5 h-0.5 rounded-full bg-current`}></div>
                            </div>
                            <span className="text-[7px] font-bold font-mono">{stamp.date}</span>
                            <div className={`absolute -bottom-2 bg-[#fdfbf7] px-2 text-[8px] font-black uppercase tracking-widest ${stamp.color}`}>
                              {stamp.type}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
