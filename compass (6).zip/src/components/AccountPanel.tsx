import React, { useState, useEffect } from 'react';
import { User, LogOut, Shield, MapPin, Calendar, Bell, Navigation, Volume2, ExternalLink, ChevronRight, AlertTriangle, Globe, LayoutPanelLeft } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface AccountPanelProps {
  user: any;
  onLogout: () => void;
  sidebarPosition: string;
  onSidebarPositionChange: (pos: any) => void;
  language: string;
  onLanguageChange: (lang: string) => void;
}

const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'tr', name: 'Türkçe' },
  { code: 'es', name: 'Español' },
  { code: 'de', name: 'Deutsch' },
  { code: 'zh', name: '中文' },
  { code: 'fr', name: 'Français' },
  { code: 'ru', name: 'Русский' },
  { code: 'ar', name: 'العربية' },
];

const POSITIONS = [
  { value: 'left', label: 'account.pos.left' },
  { value: 'right', label: 'account.pos.right' },
  { value: 'top', label: 'account.pos.top' },
  { value: 'bottom', label: 'account.pos.bottom' },
];

export function AccountPanel({ user, onLogout, sidebarPosition, onSidebarPositionChange, language, onLanguageChange }: AccountPanelProps) {
  const { t } = useLanguage();
  // Load preferences from localStorage to simulate persistence
  const [pushEnabled, setPushEnabled] = useState(() => localStorage.getItem('pref_push') === 'true');
  const [locationEnabled, setLocationEnabled] = useState(() => localStorage.getItem('pref_location') === 'true');
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('pref_sound') !== 'false');

  useEffect(() => {
    localStorage.setItem('pref_push', pushEnabled.toString());
    localStorage.setItem('pref_location', locationEnabled.toString());
    localStorage.setItem('pref_sound', soundEnabled.toString());
  }, [pushEnabled, locationEnabled, soundEnabled]);

  const handleOpenURL = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className={`absolute top-0 ${document.documentElement.dir === 'rtl' ? 'left-0 border-r' : 'right-0 border-l'} w-full md:w-[450px] h-full bg-[#0a0f12]/95 backdrop-blur-2xl border-white/10 p-0 overflow-y-auto z-40 transition-transform duration-300`}>
      
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0a0f12]/90 backdrop-blur-md border-b border-white/5 px-8 py-6">
        <h2 className="text-2xl font-bold text-white tracking-tight">{t('account.title')}</h2>
      </div>

      <div className="p-8 space-y-10">
        
        {/* Account Section */}
        <section>
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 ml-1">{t('nav.account')}</h3>
          <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
            
            {/* Profile Info */}
            <div className="p-6 flex items-center gap-4 border-b border-white/5">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-400 to-emerald-600 flex items-center justify-center shadow-lg shrink-0">
                <span className="text-2xl font-bold text-white">
                  {user?.username?.charAt(0).toUpperCase() || 'U'}
                </span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{user?.username || 'Traveler'}</h3>
                <p className="text-teal-400 text-sm font-medium">{t('account.level')}</p>
              </div>
            </div>

            {/* Account Actions */}
            <div className="flex flex-col">
              <button className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
                <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.editProfile')}</span>
                <ChevronRight className={`w-4 h-4 text-gray-500 group-hover:text-white transition-colors ${document.documentElement.dir === 'rtl' ? 'rotate-180' : ''}`} />
              </button>
              <button className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
                <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.changePassword')}</span>
                <ChevronRight className={`w-4 h-4 text-gray-500 group-hover:text-white transition-colors ${document.documentElement.dir === 'rtl' ? 'rotate-180' : ''}`} />
              </button>
              <button onClick={onLogout} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
                <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.logout')}</span>
                <LogOut className={`w-4 h-4 text-gray-500 group-hover:text-white transition-colors ${document.documentElement.dir === 'rtl' ? 'rotate-180' : ''}`} />
              </button>
              <button className="flex items-center justify-between p-4 hover:bg-red-500/10 transition-colors text-left group">
                <span className="text-red-400 font-medium group-hover:text-red-300 transition-colors">{t('account.deleteAccount')}</span>
                <AlertTriangle className="w-4 h-4 text-red-500/50 group-hover:text-red-400 transition-colors" />
              </button>
            </div>
          </div>
        </section>

        {/* Display & Interface */}
        <section>
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 ml-1">{t('account.displayInterface')}</h3>
          <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden flex flex-col">
            
            {/* Language Selection */}
            <div className="p-4 border-b border-white/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                  <Globe className="w-4 h-4 text-indigo-400" />
                </div>
                <span className="text-gray-300 font-medium">{t('account.language')}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {LANGUAGES.map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => onLanguageChange(lang.code)}
                    className={`px-3 py-2 rounded-xl text-sm font-medium transition-colors ${language === lang.code ? 'bg-teal-500/20 text-teal-400 border border-teal-500/30' : 'bg-black/20 text-gray-400 hover:bg-white/5 hover:text-white border border-transparent'}`}
                  >
                    {lang.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Sidebar Position */}
            <div className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-pink-500/20 flex items-center justify-center">
                  <LayoutPanelLeft className="w-4 h-4 text-pink-400" />
                </div>
                <span className="text-gray-300 font-medium">{t('account.navPosition')}</span>
              </div>
              <div className="flex bg-black/20 rounded-xl p-1">
                {POSITIONS.map(pos => (
                  <button
                    key={pos.value}
                    onClick={() => onSidebarPositionChange(pos.value)}
                    className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${sidebarPosition === pos.value ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                  >
                    {t(pos.label)}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </section>

        {/* Permissions & Preferences */}
        <section>
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 ml-1">{t('account.permissions')}</h3>
          <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden flex flex-col">
            
            {/* Push Notifications */}
            <div className="flex items-center justify-between p-4 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <Bell className="w-4 h-4 text-blue-400" />
                </div>
                <span className="text-gray-300 font-medium">{t('account.pushNotifications')}</span>
              </div>
              <button 
                onClick={() => setPushEnabled(!pushEnabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${pushEnabled ? 'bg-teal-500' : 'bg-gray-700'}`}
              >
                <div className={`absolute top-1 ${document.documentElement.dir === 'rtl' ? 'right-1' : 'left-1'} bg-white w-4 h-4 rounded-full transition-transform ${pushEnabled ? (document.documentElement.dir === 'rtl' ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Background Location */}
            <div className="flex items-center justify-between p-4 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                  <Navigation className="w-4 h-4 text-emerald-400" />
                </div>
                <span className="text-gray-300 font-medium">{t('account.bgLocation')}</span>
              </div>
              <button 
                onClick={() => setLocationEnabled(!locationEnabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${locationEnabled ? 'bg-teal-500' : 'bg-gray-700'}`}
              >
                <div className={`absolute top-1 ${document.documentElement.dir === 'rtl' ? 'right-1' : 'left-1'} bg-white w-4 h-4 rounded-full transition-transform ${locationEnabled ? (document.documentElement.dir === 'rtl' ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Sound Effects & Haptics */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                  <Volume2 className="w-4 h-4 text-purple-400" />
                </div>
                <span className="text-gray-300 font-medium">{t('account.soundHaptics')}</span>
              </div>
              <button 
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${soundEnabled ? 'bg-teal-500' : 'bg-gray-700'}`}
              >
                <div className={`absolute top-1 ${document.documentElement.dir === 'rtl' ? 'right-1' : 'left-1'} bg-white w-4 h-4 rounded-full transition-transform ${soundEnabled ? (document.documentElement.dir === 'rtl' ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0'}`} />
              </button>
            </div>

          </div>
        </section>

        {/* About & Legal */}
        <section>
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 ml-1">{t('account.aboutLegal')}</h3>
          <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden flex flex-col">
            
            <button onClick={() => handleOpenURL('#')} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
              <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.tos')}</span>
              <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
            </button>
            
            <button onClick={() => handleOpenURL('#')} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
              <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.privacy')}</span>
              <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
            </button>
            
            <button onClick={() => handleOpenURL('#')} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left border-b border-white/5 group">
              <span className="text-gray-300 font-medium group-hover:text-white transition-colors">{t('account.rules')}</span>
              <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
            </button>

            <div className="flex items-center justify-between p-4 bg-black/20">
              <span className="text-gray-400 font-medium">{t('account.appVersion')}</span>
              <span className="text-gray-500 font-mono text-sm">Version 1.0.2</span>
            </div>

          </div>
        </section>

        {/* Company Footer */}
        <div className="pt-8 pb-12 text-center">
          <p className="text-xs font-bold tracking-widest text-gray-600 uppercase">{t('account.createdBy')}</p>
        </div>

      </div>
    </div>
  );
}
