import { useState, useEffect, useRef } from 'react';
import { Users, Copy, Play, AlertTriangle } from 'lucide-react';

interface CoopControlsProps {
  username: string;
  userId: number;
  onSpeedChange: (speed: number) => void;
  isFocused: boolean;
}

export function CoopControls({ username, userId, onSpeedChange, isFocused }: CoopControlsProps) {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [inputRoomId, setInputRoomId] = useState('');
  const [status, setStatus] = useState<'idle' | 'waiting' | 'active' | 'penalty'>('idle');
  const [participants, setParticipants] = useState<string[]>([]);
  const [penaltyUser, setPenaltyUser] = useState<string | null>(null);

  useEffect(() => {
    // Connect to WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);
    
    ws.onopen = () => {
      console.log('Connected to Co-op Server');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'ROOM_CREATED':
            setRoomId(data.payload.roomId);
            setStatus('waiting');
            setParticipants([username]);
            break;
          
          case 'PLAYER_JOINED':
            setParticipants(prev => [...prev, data.payload.username]);
            break;

          case 'TRIP_STARTED':
            setStatus('active');
            break;

          case 'PENALTY_TRIGGERED':
            setStatus('penalty');
            setPenaltyUser(data.payload.username);
            onSpeedChange(data.payload.speed);
            break;

          case 'PENALTY_CLEARED':
            setStatus('active');
            setPenaltyUser(null);
            onSpeedChange(data.payload.speed);
            break;

          case 'PLAYER_LEFT':
            setParticipants(prev => prev.filter(p => p !== data.payload.username));
            break;
        }
      } catch (err) {
        console.error('Failed to parse WebSocket message:', err);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    setSocket(ws);

    return () => {
      ws.close();
    };
  }, [username]);

  // Send focus updates
  useEffect(() => {
    if (socket && roomId && status === 'active') {
      socket.send(JSON.stringify({
        type: 'UPDATE_FOCUS',
        payload: { focused: isFocused }
      }));
    }
  }, [isFocused, socket, roomId, status]);

  const createRoom = () => {
    if (socket) {
      socket.send(JSON.stringify({
        type: 'CREATE_ROOM',
        payload: { userId, username }
      }));
    }
  };

  const joinRoom = () => {
    if (socket && inputRoomId) {
      socket.send(JSON.stringify({
        type: 'JOIN_ROOM',
        payload: { roomId: inputRoomId, userId, username }
      }));
      setRoomId(inputRoomId);
      setStatus('waiting');
    }
  };

  const startTrip = () => {
    if (socket && roomId) {
      socket.send(JSON.stringify({
        type: 'START_TRIP'
      }));
    }
  };

  if (!userId) return null;

  return (
    <div className="fixed top-24 right-8 z-50 w-80 bg-[#0a0f12]/90 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl">
      <div className="flex items-center gap-3 mb-4">
        <Users className="w-5 h-5 text-teal-400" />
        <h3 className="text-white font-semibold">Co-op Mode</h3>
      </div>

      {status === 'idle' && (
        <div className="flex flex-col gap-3">
          <button 
            onClick={createRoom}
            className="w-full py-3 bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/50 text-teal-400 rounded-xl transition-all"
          >
            Create Room
          </button>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Room Code"
              value={inputRoomId}
              onChange={(e) => setInputRoomId(e.target.value.toUpperCase())}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 text-white placeholder-white/30"
            />
            <button 
              onClick={joinRoom}
              className="px-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl"
            >
              Join
            </button>
          </div>
        </div>
      )}

      {status === 'waiting' && (
        <div className="space-y-4">
          <div className="bg-white/5 rounded-xl p-4 border border-white/10">
            <p className="text-xs text-gray-400 mb-1">ROOM CODE</p>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-mono text-white tracking-widest">{roomId}</span>
              <button onClick={() => navigator.clipboard.writeText(roomId || '')}>
                <Copy className="w-4 h-4 text-gray-400 hover:text-white" />
              </button>
            </div>
          </div>
          
          <div>
            <p className="text-sm text-gray-400 mb-2">Participants ({participants.length})</p>
            <div className="flex flex-wrap gap-2">
              {participants.map((p, i) => (
                <span key={i} className="px-3 py-1 bg-teal-500/10 text-teal-400 rounded-full text-sm border border-teal-500/20">
                  {p}
                </span>
              ))}
            </div>
          </div>

          <button 
            onClick={startTrip}
            className="w-full py-3 bg-teal-500 text-black font-bold rounded-xl hover:bg-teal-400 transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4" /> Start Together
          </button>
        </div>
      )}

      {status === 'active' && (
        <div className="text-center py-4">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-500/20 text-green-400 mb-2">
            <Play className="w-6 h-6" />
          </div>
          <p className="text-white font-medium">Trip in Progress</p>
          <p className="text-sm text-gray-400">Stay focused to keep speed at 100%</p>
        </div>
      )}

      {status === 'penalty' && (
        <div className="bg-red-500/10 border border-red-500/50 rounded-xl p-4 animate-pulse">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-6 h-6 text-red-500" />
            <h4 className="text-red-400 font-bold">SPEED REDUCED!</h4>
          </div>
          <p className="text-sm text-white/80">
            <span className="font-bold text-white">{penaltyUser}</span> lost focus!
          </p>
          <p className="text-xs text-red-300 mt-2">Speed dropped to 50%</p>
        </div>
      )}
    </div>
  );
}
