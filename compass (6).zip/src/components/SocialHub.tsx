import React, { useState, useEffect, useRef } from 'react';
import { Users, Search, UserPlus, Check, X, BookOpen, Globe, Copy, Play, AlertTriangle, Trash2, Edit2, MapPin, Clock, History } from 'lucide-react';
import { PassportPreview } from './PassportPreview';
import { CoopState } from '../hooks/useCoop';
import { calculateDistance } from '../utils/distance';
import { CitySearchInput, LocationData } from './CitySearchInput';
import { useLanguage } from '../contexts/LanguageContext';

interface Friend {
  id: number;
  username: string;
  status: 'pending' | 'accepted' | 'pending_outgoing';
  type: 'friend' | 'request' | 'pending_outgoing';
}

interface SocialHubProps {
  userId: number;
  onViewPassport: (userId: number) => void;
  onClose: () => void;
  coop?: CoopState;
  userLocation: { lat: number; lng: number };
}

export function SocialHub({ userId, onViewPassport, onClose, coop, userLocation }: SocialHubProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'friends' | 'add' | 'coop' | 'history'>('friends');
  const [friends, setFriends] = useState<Friend[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [inputRoomId, setInputRoomId] = useState('');
  const [history, setHistory] = useState<any[]>([]);
  
  // Room Creation State
  const [selectedCity, setSelectedCity] = useState<LocationData | null>(null);
  const [citySearch, setCitySearch] = useState('');
  const [transportMode, setTransportMode] = useState('plane');
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  const [isEditingRoom, setIsEditingRoom] = useState(false);
  const [estimatedTime, setEstimatedTime] = useState<string>('');
  
  // Hover Preview State
  const [hoveredUser, setHoveredUser] = useState<{ id: number; x: number; y: number; isFriend: boolean; isPending: boolean } | null>(null);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (userId) {
      fetchFriends();
    }
  }, [userId]);

  useEffect(() => {
    if (activeTab === 'history' && userId) {
      fetchHistory();
    }
  }, [activeTab, userId]);

  const fetchHistory = async () => {
    try {
      const res = await fetch(`/api/coop/history/${userId}`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setHistory(data);
      }
    } catch (e) {
      console.error("Error fetching history:", e);
    }
  };

  // Calculate estimated time
  useEffect(() => {
    if (selectedCity && userLocation) {
      const dist = calculateDistance(userLocation.lat, userLocation.lng, selectedCity.lat, selectedCity.lng);
      let speed = 900; // Plane
      if (transportMode === 'car') speed = 100;
      if (transportMode === 'foot') speed = 5;
      
      const hours = dist / speed;
      const mins = Math.round(hours * 60);
      
      if (mins < 60) {
        setEstimatedTime(`${mins} min`);
      } else {
        setEstimatedTime(`${Math.floor(mins / 60)}h ${mins % 60}m`);
      }
    } else {
      setEstimatedTime('');
    }
  }, [selectedCity, transportMode, userLocation]);

  // Sync edit state with current room details
  useEffect(() => {
    if (isEditingRoom && coop?.destination) {
      // We don't have lat/lng for existing destination string easily unless we search again or store it.
      // For now, just set the name.
      setCitySearch(coop.destination);
      if (coop.transportMode) {
        setTransportMode(coop.transportMode);
      }
    }
  }, [isEditingRoom, coop?.destination, coop?.transportMode]);

  const handleMouseEnter = (user: any, event: React.MouseEvent, isFriend: boolean, isPending: boolean) => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    setHoveredUser({
      id: user.id,
      x: rect.right, // Position to the right of the card
      y: rect.top + (rect.height / 2),
      isFriend,
      isPending
    });
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setHoveredUser(null);
    }, 300); // Small delay to allow moving to the popup if needed
  };

  const fetchFriends = async () => {
    try {
      const res = await fetch(`/api/friends/${userId}`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setFriends(data);
      } else {
        console.error("Failed to fetch friends:", data);
        setFriends([]);
      }
    } catch (e) {
      console.error("Error fetching friends:", e);
      setFriends([]);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length > 2) {
      try {
        const res = await fetch(`/api/users/search?query=${query}&excludeId=${userId}`);
        const data = await res.json();
        if (Array.isArray(data)) {
          setSearchResults(data);
        } else {
          setSearchResults([]);
        }
      } catch (e) {
        setSearchResults([]);
      }
    } else {
      setSearchResults([]);
    }
  };

  const sendRequest = async (receiverId: number) => {
    await fetch('/api/friends/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senderId: userId, receiverId })
    });
    fetchFriends();
    setSearchResults([]);
    setSearchQuery('');
    setActiveTab('friends');
  };

  const acceptRequest = async (friendId: number) => {
    await fetch('/api/friends/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, friendId })
    });
    fetchFriends();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-[#0a0f12] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" /> {t('social.title')}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 overflow-x-auto">
          <button
            onClick={() => setActiveTab('friends')}
            className={`flex-1 py-3 text-sm font-medium transition-colors min-w-[80px] ${
              activeTab === 'friends' ? 'text-indigo-400 border-b-2 border-indigo-400 bg-white/5' : 'text-gray-400 hover:text-white'
            }`}
          >
            {t('social.friends')}
          </button>
          <button
            onClick={() => setActiveTab('add')}
            className={`flex-1 py-3 text-sm font-medium transition-colors min-w-[80px] ${
              activeTab === 'add' ? 'text-indigo-400 border-b-2 border-indigo-400 bg-white/5' : 'text-gray-400 hover:text-white'
            }`}
          >
            {t('social.discovery')}
          </button>
          <button
            onClick={() => setActiveTab('coop')}
            className={`flex-1 py-3 text-sm font-medium transition-colors min-w-[80px] ${
              activeTab === 'coop' ? 'text-teal-400 border-b-2 border-teal-400 bg-white/5' : 'text-gray-400 hover:text-white'
            }`}
          >
            {t('social.coop')}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 text-sm font-medium transition-colors min-w-[80px] ${
              activeTab === 'history' ? 'text-amber-400 border-b-2 border-amber-400 bg-white/5' : 'text-gray-400 hover:text-white'
            }`}
          >
            {t('social.history')}
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 relative">
          {/* Passport Preview Popup */}
          {hoveredUser && (
            <div 
              onMouseEnter={() => {
                if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
              }}
              onMouseLeave={() => setHoveredUser(null)}
            >
              <PassportPreview 
                userId={hoveredUser.id} 
                position={{ x: hoveredUser.x, y: hoveredUser.y }} 
                onClose={() => setHoveredUser(null)}
                onAddFriend={sendRequest}
                isFriend={hoveredUser.isFriend}
                isPending={hoveredUser.isPending}
              />
            </div>
          )}

          {activeTab === 'friends' && (
            <div className="space-y-4">
              {friends.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">{t('social.noFriends')}</p>
                  <button 
                    onClick={async () => {
                      await fetch('/api/debug/seed-friend', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId })
                      });
                      fetchFriends();
                    }}
                    className="px-4 py-2 bg-indigo-500/20 text-indigo-400 rounded-lg hover:bg-indigo-500/30 text-sm font-bold"
                  >
                    + Add Example Friend
                  </button>
                </div>
              )}
              
              {/* Requests Section */}
              {friends.some(f => f.type === 'request') && (
                <div className="mb-6">
                  <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-3">{t('social.requests')}</h3>
                  <div className="space-y-2">
                    {friends.filter(f => f.type === 'request').map(req => (
                      <div key={req.id} className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/10">
                        <span className="text-white font-medium">{req.username}</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => acceptRequest(req.id)}
                            className="p-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Friends List */}
              <div className="space-y-2">
                {friends.filter(f => f.type === 'friend').map(friend => (
                  <div 
                    key={friend.id} 
                    className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/10 hover:bg-white/10 transition-colors group relative"
                    onMouseEnter={(e) => handleMouseEnter(friend, e, true, false)}
                    onMouseLeave={handleMouseLeave}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold">
                        {friend.username[0].toUpperCase()}
                      </div>
                      <span className="text-white font-medium">{friend.username}</span>
                    </div>
                    <button 
                      onClick={() => onViewPassport(friend.id)}
                      className="px-3 py-1.5 bg-white/10 text-xs text-white rounded-lg hover:bg-white/20 flex items-center gap-2"
                    >
                      <BookOpen className="w-3 h-3" /> {t('social.passport')}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'add' && (
            <div className="space-y-4">
              <div className="relative">
                <Search className={`absolute ${document.documentElement.dir === 'rtl' ? 'right-3' : 'left-3'} top-3 w-5 h-5 text-gray-400`} />
                <input
                  type="text"
                  placeholder={t('social.searchUsers')}
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className={`w-full bg-white/5 border border-white/10 rounded-xl py-2.5 ${document.documentElement.dir === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'} text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500`}
                />
              </div>

              <div className="space-y-2 mt-4">
                {searchResults.map(user => {
                  const isFriend = friends.some(f => f.id === user.id && f.type === 'friend');
                  const isPending = friends.some(f => f.id === user.id && (f.type === 'pending_outgoing' || f.type === 'request'));

                  return (
                    <div 
                      key={user.id} 
                      className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                      onMouseEnter={(e) => handleMouseEnter(user, e, isFriend, isPending)}
                      onMouseLeave={handleMouseLeave}
                      onClick={() => {}}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-gray-300 font-bold">
                          {user.username[0].toUpperCase()}
                        </div>
                        <span className="text-white font-medium">{user.username}</span>
                      </div>
                      
                      {isFriend ? (
                        <span className="text-xs text-green-400 px-3 py-1 bg-green-500/10 rounded-lg flex items-center gap-1">
                          <Check className="w-3 h-3" /> {t('social.friend')}
                        </span>
                      ) : isPending ? (
                        <span className="text-xs text-yellow-400 px-3 py-1 bg-yellow-500/10 rounded-lg">{t('social.pending')}</span>
                      ) : (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            sendRequest(user.id);
                          }}
                          className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg hover:bg-indigo-500/30"
                        >
                          <UserPlus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'coop' && coop && (
            <div className="space-y-6">
              <div className="bg-teal-500/10 border border-teal-500/20 rounded-xl p-4">
                <h3 className="text-teal-400 font-bold mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4" /> {t('social.coopMode')}
                </h3>
                <p className="text-xs text-gray-400">
                  {t('social.coopDesc')}
                </p>
              </div>

              {coop.status === 'idle' && (
                <div className="space-y-4">
                  {!isCreatingRoom ? (
                    <>
                      <button 
                        onClick={() => setIsCreatingRoom(true)}
                        className="w-full py-3 bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/50 text-teal-400 rounded-xl transition-all font-bold"
                      >
                        {t('social.createRoom')}
                      </button>
                      
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <div className="w-full border-t border-white/10"></div>
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-[#0a0f12] px-2 text-gray-500">{t('social.orJoin')}</span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder={t('social.enterCode')}
                          value={inputRoomId}
                          onChange={(e) => setInputRoomId(e.target.value.toUpperCase())}
                          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-teal-500"
                        />
                        <button 
                          onClick={() => coop.joinRoom(inputRoomId)}
                          disabled={!inputRoomId}
                          className="px-6 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {t('social.join')}
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-white font-bold">{t('social.tripDetails')}</h4>
                        <button onClick={() => {
                          setIsCreatingRoom(false);
                          setCitySearch('');
                          setSelectedCity(null);
                        }} className="text-xs text-gray-400 hover:text-white">{t('transport.cancel')}</button>
                      </div>
                      
                      <div className="space-y-2 relative">
                        <label className="text-xs text-gray-400 uppercase font-bold">{t('ticket.to')}</label>
                        <CitySearchInput
                          placeholder={t('floating.searchDest')}
                          value={citySearch}
                          onChange={(value, location) => {
                            setCitySearch(value);
                            if (location) setSelectedCity(location);
                            else setSelectedCity(null);
                          }}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs text-gray-400 uppercase font-bold">{t('social.transport')}</label>
                        <div className="grid grid-cols-3 gap-2">
                          {['plane', 'car', 'foot'].map((mode) => (
                            <button
                              key={mode}
                              onClick={() => setTransportMode(mode)}
                              className={`py-2 rounded-lg text-sm capitalize border ${
                                transportMode === mode 
                                  ? 'bg-teal-500/20 border-teal-500 text-teal-400' 
                                  : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                              }`}
                            >
                              {t(`transport.${mode}`)}
                            </button>
                          ))}
                        </div>
                      </div>

                      {estimatedTime && (
                        <div className="flex items-center gap-2 text-teal-400 bg-teal-500/10 p-3 rounded-xl border border-teal-500/20">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm font-bold">{t('social.estTime')}: {estimatedTime}</span>
                        </div>
                      )}

                      <button 
                        onClick={() => coop.createRoom(selectedCity?.name || citySearch, transportMode)}
                        disabled={!selectedCity && !citySearch}
                        className="w-full py-3 bg-teal-500 text-black font-bold rounded-xl hover:bg-teal-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-4"
                      >
                        {t('social.generateCode')}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {coop.status === 'waiting' && (
                <div className="space-y-6">
                  {!isEditingRoom ? (
                    <>
                      <div className="bg-white/5 rounded-xl p-6 border border-white/10 text-center relative overflow-hidden">
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">{t('social.roomCode')}</p>
                        <div className="flex items-center justify-center gap-3 mb-4">
                          <span className="text-4xl font-mono text-white tracking-widest font-bold">{coop.roomId}</span>
                          <button 
                            onClick={() => navigator.clipboard.writeText(coop.roomId || '')}
                            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                          >
                            <Copy className="w-5 h-5 text-teal-400" />
                          </button>
                        </div>
                        
                        <div className="pt-4 border-t border-white/10 flex justify-center gap-6">
                           <div className="text-center">
                              <p className="text-[10px] text-gray-500 uppercase font-bold">{t('ticket.to')}</p>
                              <p className="text-sm text-white font-medium">{coop.destination || 'Unknown'}</p>
                           </div>
                           <div className="text-center">
                              <p className="text-[10px] text-gray-500 uppercase font-bold">{t('social.transport')}</p>
                              <p className="text-sm text-white font-medium capitalize">{coop.transportMode ? t(`transport.${coop.transportMode}`) : 'Unknown'}</p>
                           </div>
                        </div>

                        {coop.isHost && (
                          <button 
                            onClick={() => setIsEditingRoom(true)}
                            className={`absolute top-2 ${document.documentElement.dir === 'rtl' ? 'left-2' : 'right-2'} p-2 text-gray-500 hover:text-white transition-colors`}
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-400 mb-3 font-medium">{t('social.participants')} ({coop.participants.length})</p>
                        <div className="flex flex-wrap gap-2">
                          {coop.participants.map((p, i) => (
                            <span key={i} className="px-3 py-1.5 bg-teal-500/10 text-teal-400 rounded-lg text-sm border border-teal-500/20 flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-teal-500"></div>
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>

                      {coop.isHost && (
                        <div className="space-y-3">
                          <button 
                            onClick={() => {
                              coop.startTrip();
                              onClose(); // Close modal to show map
                            }}
                            className="w-full py-4 bg-teal-500 text-black font-bold rounded-xl hover:bg-teal-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20"
                          >
                            <Play className="w-5 h-5 fill-current" /> {t('social.startTrip')}
                          </button>

                          <button 
                            onClick={() => {
                              if (confirm('Are you sure you want to remove this room?')) {
                                coop.removeRoom();
                              }
                            }}
                            className="w-full py-3 bg-red-500/10 text-red-400 font-bold rounded-xl hover:bg-red-500/20 transition-all flex items-center justify-center gap-2 border border-red-500/20"
                          >
                            <Trash2 className="w-4 h-4" /> {t('social.removeRoom')}
                          </button>
                        </div>
                      )}
                      
                      {!coop.isHost && (
                        <div className="text-center text-gray-500 text-sm py-4 animate-pulse">
                          {t('social.waitingHost')}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-white font-bold">{t('social.editRoom')}</h4>
                        <button onClick={() => setIsEditingRoom(false)} className="text-xs text-gray-400 hover:text-white">{t('transport.cancel')}</button>
                      </div>
                      
                      <div className="space-y-2 relative">
                        <label className="text-xs text-gray-400 uppercase font-bold">{t('ticket.to')}</label>
                        <CitySearchInput
                          placeholder={t('floating.searchDest')}
                          value={citySearch}
                          onChange={(value, location) => {
                            setCitySearch(value);
                            if (location) setSelectedCity(location);
                            else setSelectedCity(null);
                          }}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs text-gray-400 uppercase font-bold">{t('social.transport')}</label>
                        <div className="grid grid-cols-3 gap-2">
                          {['plane', 'car', 'foot'].map((mode) => (
                            <button
                              key={mode}
                              onClick={() => setTransportMode(mode)}
                              className={`py-2 rounded-lg text-sm capitalize border ${
                                transportMode === mode 
                                  ? 'bg-teal-500/20 border-teal-500 text-teal-400' 
                                  : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                              }`}
                            >
                              {t(`transport.${mode}`)}
                            </button>
                          ))}
                        </div>
                      </div>

                      {estimatedTime && (
                        <div className="flex items-center gap-2 text-teal-400 bg-teal-500/10 p-3 rounded-xl border border-teal-500/20">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm font-bold">{t('social.estTime')}: {estimatedTime}</span>
                        </div>
                      )}

                      <button 
                        onClick={() => {
                          coop.updateRoom(selectedCity?.name || citySearch, transportMode);
                          setIsEditingRoom(false);
                        }}
                        className="w-full py-3 bg-teal-500 text-black font-bold rounded-xl hover:bg-teal-400 transition-all mt-4"
                      >
                        {t('social.updateRoom')}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {(coop.status === 'active' || coop.status === 'penalty') && (
                <div className="text-center py-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 text-green-400 mb-4 animate-pulse">
                    <Play className="w-8 h-8 fill-current" />
                  </div>
                  <h3 className="text-white font-bold text-lg mb-1">{t('social.tripInProgress')}</h3>
                  <p className="text-sm text-gray-400 mb-6">{t('social.tripInProgressDesc')}</p>
                  
                  <button 
                    onClick={onClose}
                    className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm"
                  >
                    {t('social.closeViewMap')}
                  </button>
                </div>
              )}
            </div>
          )}
          {activeTab === 'history' && (
            <div className="space-y-4">
              {history.length === 0 ? (
                <div className="text-center py-12">
                  <History className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-500">{t('social.noHistory')}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {history.map((trip: any, idx: number) => (
                    <div key={trip.id || idx} className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-colors">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="text-white font-bold text-lg flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-teal-400" />
                            {trip.destination}
                          </h3>
                          <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(trip.end_time).toLocaleDateString()} • {new Date(trip.end_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-teal-400 font-bold text-sm bg-teal-500/10 px-2 py-1 rounded-lg inline-block mb-1">
                            {trip.duration_minutes} min
                          </div>
                          <p className="text-xs text-gray-500 capitalize flex items-center justify-end gap-1">
                            {t(`transport.${trip.transport_mode}`)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="border-t border-white/10 pt-3">
                        <p className="text-[10px] text-gray-500 uppercase font-bold mb-2">{t('social.travelCompanions')}</p>
                        <div className="flex flex-wrap gap-2">
                          {trip.participants && trip.participants.map((p: string, i: number) => (
                            <span key={i} className="px-2 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded text-xs flex items-center gap-1">
                              <div className="w-1.5 h-1.5 rounded-full bg-indigo-400"></div>
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
