import { AlertTriangle, Play, Users } from 'lucide-react';
import { CoopState } from '../hooks/useCoop';

interface CoopStatusWidgetProps {
  coop: CoopState;
}

export function CoopStatusWidget({ coop }: CoopStatusWidgetProps) {
  if (coop.status === 'idle' || coop.status === 'waiting') return null;

  return (
    <div className="fixed top-24 right-8 z-40 bg-[#0a0f12]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-xl w-64">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 text-teal-400 font-bold text-sm">
          <Users className="w-4 h-4" />
          <span>CO-OP ACTIVE</span>
        </div>
        <div className="text-xs text-gray-400">{coop.participants.length} Players</div>
      </div>

      {coop.status === 'penalty' ? (
        <div className="bg-red-500/10 border border-red-500/50 rounded-xl p-3 animate-pulse">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <span className="text-red-400 font-bold text-xs">SPEED REDUCED</span>
          </div>
          <p className="text-xs text-white">
            <span className="font-bold">{coop.penaltyUser}</span> lost focus!
          </p>
        </div>
      ) : (
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3">
          <div className="flex items-center gap-2">
            <Play className="w-4 h-4 text-green-400 fill-current" />
            <span className="text-green-400 font-bold text-xs">FULL SPEED</span>
          </div>
        </div>
      )}
    </div>
  );
}
