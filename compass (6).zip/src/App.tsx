import { useState, useEffect, useRef } from 'react';
import { Sidebar, TabName, SidebarPosition } from './components/Sidebar';
import { MapCanvas } from './components/MapCanvas';
import { FloatingWidgets } from './components/FloatingWidgets';
import { useFlightTimer } from './hooks/useFlightTimer';
import { LocationData } from './components/CitySearchInput';
import { TransportModal, TransportMode } from './components/TransportModal';
import { TicketModal } from './components/TicketModal';
import { PassportPanel } from './components/PassportPanel';
import { MarketPanel } from './components/MarketPanel';
import { TravelHistoryPanel, TravelHistoryItem } from './components/TravelHistoryPanel';
import { VisaAlertModal } from './components/VisaAlertModal';
import { AccountPanel } from './components/AccountPanel';
import { AuthScreen } from './components/AuthScreen';
import { AudioProvider, useAudio } from './components/AudioManager';
import { SocialHub } from './components/SocialHub';
import { PassportModal } from './components/PassportModal';
import { useCoop } from './hooks/useCoop';
import { CoopStatusWidget } from './components/CoopStatusWidget';
import { MapStatsOverlay } from './components/MapStatsOverlay';
import { calculateUserStats } from './utils/stats';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';

const DEFAULT_START = { lat: 51.5074, lng: -0.1278 }; // London

// Map ISO country codes to Visa IDs and Names
const VISA_REQUIREMENTS: Record<string, { id: string, name: string }> = {
  'US': { id: 'USA', name: 'United States' },
  'JP': { id: 'JPN', name: 'Japan' },
  'AU': { id: 'AUS', name: 'Australia' },
  // Schengen Area
  'FR': { id: 'Schengen', name: 'Schengen Area' }, 
  'DE': { id: 'Schengen', name: 'Schengen Area' }, 
  'IT': { id: 'Schengen', name: 'Schengen Area' }, 
  'ES': { id: 'Schengen', name: 'Schengen Area' }, 
  'NL': { id: 'Schengen', name: 'Schengen Area' }, 
  'BE': { id: 'Schengen', name: 'Schengen Area' }, 
  'AT': { id: 'Schengen', name: 'Schengen Area' }, 
  'GR': { id: 'Schengen', name: 'Schengen Area' }, 
  'PT': { id: 'Schengen', name: 'Schengen Area' }, 
  'SE': { id: 'Schengen', name: 'Schengen Area' }, 
  'FI': { id: 'Schengen', name: 'Schengen Area' }, 
  'DK': { id: 'Schengen', name: 'Schengen Area' }, 
  'PL': { id: 'Schengen', name: 'Schengen Area' }, 
  'CZ': { id: 'Schengen', name: 'Schengen Area' }, 
  'HU': { id: 'Schengen', name: 'Schengen Area' }, 
  'SK': { id: 'Schengen', name: 'Schengen Area' }, 
  'SI': { id: 'Schengen', name: 'Schengen Area' }, 
  'EE': { id: 'Schengen', name: 'Schengen Area' }, 
  'LV': { id: 'Schengen', name: 'Schengen Area' }, 
  'LT': { id: 'Schengen', name: 'Schengen Area' }, 
  'MT': { id: 'Schengen', name: 'Schengen Area' }, 
  'LU': { id: 'Schengen', name: 'Schengen Area' }, 
  'HR': { id: 'Schengen', name: 'Schengen Area' }, 
  'IS': { id: 'Schengen', name: 'Schengen Area' }, 
  'LI': { id: 'Schengen', name: 'Schengen Area' }, 
  'NO': { id: 'Schengen', name: 'Schengen Area' }, 
  'CH': { id: 'Schengen', name: 'Schengen Area' },
};

// Simple distance calculation (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * (Math.PI /  180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ; 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const d = R * c; // Distance in km
  return d;
}

function AppContent() {
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<TabName>('Focus');
  const [currentCountry, setCurrentCountry] = useState<string>('');
  
  const [sidebarPosition, setSidebarPosition] = useState<SidebarPosition>(() => (localStorage.getItem('pref_sidebar') as SidebarPosition) || 'left');
  const { language, setLanguage } = useLanguage();

  useEffect(() => {
    localStorage.setItem('pref_sidebar', sidebarPosition);
  }, [sidebarPosition]);
  
  const [hasStarted, setHasStarted] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1.0);
  
  const [startLocationName, setStartLocationName] = useState('');
  const [endLocationName, setEndLocationName] = useState('');
  
  const [startCoords, setStartCoords] = useState(DEFAULT_START);
  const [endCoords, setEndCoords] = useState(DEFAULT_START);
  const [endLocationData, setEndLocationData] = useState<LocationData | null>(null);
  const [viewingPassportId, setViewingPassportId] = useState<number | null>(null);
  
  const [totalDistance, setTotalDistance] = useState(0);
  const [totalDuration, setTotalDuration] = useState(25 * 60);
  
  const [transportMode, setTransportMode] = useState<TransportMode>('plane');
  const [showTransportModal, setShowTransportModal] = useState(false);
  const [showTicketModal, setShowTicketModal] = useState(false);

  // Global State
  const [focusMiles, setFocusMiles] = useState(2500);
  const [ownedVisas, setOwnedVisas] = useState<string[]>(['Schengen']); // Start with only Schengen
  const [travelHistory, setTravelHistory] = useState<TravelHistoryItem[]>([
    { city: 'Tokyo', country: 'Japan', date: '2023-10-15', duration: '25m', type: 'plane' },
    { city: 'Paris', country: 'France', date: '2023-11-02', duration: '50m', type: 'car' },
    { city: 'New York', country: 'USA', date: '2023-12-10', duration: '1h 30m', type: 'plane' },
  ]);

  // Visa Alert State
  const [visaAlert, setVisaAlert] = useState<{ show: boolean, cityName: string, visaName: string }>({
    show: false,
    cityName: '',
    visaName: ''
  });

  // Passport Data State
  const [passportData, setPassportData] = useState({
    surname: 'Traveler',
    givenNames: 'Focus',
    nationality: 'Earth',
    dob: '01 JAN 2024',
    sex: 'U',
    pob: 'Internet',
    photo: '' // Empty string for default icon, or base64/url
  });

  const { playAmbient, stopAmbient } = useAudio();

  // Co-op Hook
  const coop = useCoop(
    user?.username || '', 
    user?.id || 0, 
    setSpeedMultiplier
  );

  // Save progress to backend
  const saveProgress = async (newMiles: number, newVisas: string[], newHistory: TravelHistoryItem[], newPassportData?: any) => {
    if (!user) return;
    try {
      await fetch('/api/save-progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: user.id,
          balance: newMiles,
          ownedVisas: newVisas,
          travelHistory: newHistory,
          passportData: newPassportData || passportData
        })
      });
    } catch (err) {
      console.error('Failed to save progress', err);
    }
  };

  const handleLogin = (userData: any) => {
    setUser(userData);
    setFocusMiles(userData.balance);
    setOwnedVisas(userData.ownedVisas.length > 0 ? userData.ownedVisas : ['Schengen']);
    setTravelHistory(userData.travelHistory.length > 0 ? userData.travelHistory : [
      { city: 'Tokyo', country: 'Japan', date: '2023-10-15', duration: '25m', type: 'plane' },
      { city: 'Paris', country: 'France', date: '2023-11-02', duration: '50m', type: 'car' },
      { city: 'New York', country: 'USA', date: '2023-12-10', duration: '1h 30m', type: 'plane' },
    ]);
    if (userData.passportData) {
      setPassportData(userData.passportData);
    }
  };

  const handleUpdatePassport = (newData: any) => {
    setPassportData(newData);
    saveProgress(focusMiles, ownedVisas, travelHistory, newData);
  };

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setStartCoords({ lat: latitude, lng: longitude });
          setStartLocationName('Current Location');
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  // Earn Focus Miles while active
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive) {
      interval = setInterval(() => {
        setFocusMiles(prev => prev + 1);
      }, 1000); // Earn 1 mile per second of focus
      
      // Update Co-op Focus
      coop.updateFocus(true);
    } else {
      coop.updateFocus(false);
    }
    return () => clearInterval(interval);
  }, [isActive, coop]);

  const {
    formattedTime,
    distanceRemaining,
    currentCoords,
  } = useFlightTimer(
    startCoords,
    endCoords,
    totalDuration,
    totalDistance,
    isActive,
    speedMultiplier
  );

  // Update Co-op Location (Throttled)
  const lastUpdateRef = useRef(0);
  useEffect(() => {
    const now = Date.now();
    if (isActive && coop.status === 'active' && now - lastUpdateRef.current > 2000) {
      const progress = totalDistance > 0 ? Math.max(0, Math.min(100, 100 - (parseFloat(distanceRemaining) / totalDistance) * 100)) : 0;
      coop.updateLocation(currentCoords.lat, currentCoords.lng, progress);
      lastUpdateRef.current = now;
    }
  }, [currentCoords, isActive, coop.status, distanceRemaining, totalDistance, coop]);

  // Fetch current country name
  useEffect(() => {
    if (currentCoords.lat && currentCoords.lng) {
      const fetchCountry = async () => {
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${currentCoords.lat}&lon=${currentCoords.lng}`);
          const data = await res.json();
          if (data.address && data.address.country) {
            setCurrentCountry(data.address.country);
          }
        } catch (e) {
          console.error("Failed to fetch country", e);
        }
      };
      // Debounce slightly to avoid too many requests during flight
      const timer = setTimeout(fetchCountry, 2000);
      return () => clearTimeout(timer);
    }
  }, [currentCoords.lat, currentCoords.lng]);

  const handleStartLocationChange = (name: string, data?: LocationData) => {
    setStartLocationName(name);
    if (data) {
      setStartCoords({ lat: data.lat, lng: data.lng });
    }
  };

  const handleEndLocationChange = (name: string, data?: LocationData) => {
    if (data) {
      setEndLocationData(data);
      const countryCode = data.countryCode.toUpperCase();
      const requiredVisa = VISA_REQUIREMENTS[countryCode];
      
      if (requiredVisa && !ownedVisas.includes(requiredVisa.id) && !ownedVisas.includes('GLOBAL')) {
        setVisaAlert({
          show: true,
          cityName: name,
          visaName: requiredVisa.name
        });
        setEndLocationName(''); // Reset the input
        return;
      }

      setEndLocationName(name);
      setEndCoords({ lat: data.lat, lng: data.lng });
    } else {
      setEndLocationName(name);
    }
  };

  const handlePrepareTrip = () => {
    setShowTransportModal(true);
  };

  const handleSelectTransport = (mode: TransportMode) => {
    setTransportMode(mode);
    setShowTransportModal(false);

    const dist = calculateDistance(startCoords.lat, startCoords.lng, endCoords.lat, endCoords.lng);
    setTotalDistance(dist);

    let speed = 900; // km/h
    if (mode === 'car') speed = 100;
    if (mode === 'foot') speed = 5;

    const durationHours = dist / speed;
    const durationSeconds = Math.max(60, Math.floor(durationHours * 3600)); // Minimum 1 minute
    setTotalDuration(durationSeconds);

    if (mode === 'plane') {
      setShowTicketModal(true);
    } else {
      startActualTrip();
    }
  };

  const startActualTrip = () => {
    setShowTicketModal(false);
    setHasStarted(true);
    setIsActive(true);
    playAmbient('cabin');
    
    // Start Co-op Trip if in a room
    if (coop.status === 'waiting') {
      coop.startTrip();
    }
  };

  const handlePause = () => {
    setIsActive(!isActive);
    if (isActive) {
      // Pausing, save progress
      saveProgress(focusMiles, ownedVisas, travelHistory);
      stopAmbient();
    } else {
      playAmbient('cabin');
    }
  };
  
  const handleEndTrip = async () => {
    // Add to travel history
    const parts = endLocationName.split(',');
    const city = parts[0] || 'Unknown City';
    const country = parts.length > 1 ? parts[parts.length - 1].trim() : 'Unknown Country';
    
    const newTrip: TravelHistoryItem = {
      city,
      country,
      date: new Date().toISOString().split('T')[0],
      duration: Math.floor(totalDuration / 60) + 'm',
      type: transportMode
    };

    // Record visit in DB
    if (user && endLocationData) {
      try {
        await fetch('/api/trips/finish', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: user.id,
            countryCode: endLocationData.countryCode,
            countryName: endLocationData.country,
            duration: Math.floor(totalDuration / 60)
          })
        });
      } catch (e) {
        console.error("Failed to record trip finish", e);
      }
    }

    const newHistory = [newTrip, ...travelHistory];
    setTravelHistory(newHistory);
    
    setHasStarted(false);
    setIsActive(false);
    setEndLocationName('');
    setTotalDistance(0);
    stopAmbient();
    
    saveProgress(focusMiles, ownedVisas, newHistory);
    
    // Use a custom toast or modal in a real app, but for now we'll keep this simple alert
    // since it happens after a long session
    alert(`Trip Ended! You earned Focus Miles and arrived in ${city}.`);
  };

  const handleBuyVisa = (id: string, price: number) => {
    if (ownedVisas.includes(id)) return;
    if (focusMiles >= price) {
      const newMiles = focusMiles - price;
      const newVisas = [...ownedVisas, id];
      setFocusMiles(newMiles);
      setOwnedVisas(newVisas);
      saveProgress(newMiles, newVisas, travelHistory);
    } else {
      alert('Not enough Focus Miles!');
    }
  };

  const handleLogout = () => {
    if (isActive) {
      saveProgress(focusMiles, ownedVisas, travelHistory);
    }
    setUser(null);
    setIsActive(false);
    setHasStarted(false);
    stopAmbient();
  };

  if (!user) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  const getLayoutClasses = () => {
    switch (sidebarPosition) {
      case 'right': return 'flex-row-reverse';
      case 'top': return 'flex-col';
      case 'bottom': return 'flex-col-reverse';
      case 'left':
      default: return 'flex-row';
    }
  };

  return (
    <div className={`flex h-screen w-full bg-[#0a0f12] overflow-hidden font-sans text-white ${getLayoutClasses()}`}>
      {/* Sidebar (Navigation) */}
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} position={sidebarPosition} />

      {/* Main Content Area */}
      <main className="flex-1 relative h-full overflow-hidden">
        {/* Map Canvas (Background) */}
        <MapCanvas
          currentCoords={hasStarted ? currentCoords : startCoords}
          startCoords={startCoords}
          endCoords={hasStarted ? endCoords : startCoords}
          transportMode={transportMode}
          activeTab={activeTab}
          travelHistory={travelHistory}
          participantLocations={coop.participantLocations}
          currentCountry={currentCountry}
        />

        {/* Map Stats Overlay */}
        {activeTab === 'Map' && (
          <MapStatsOverlay stats={calculateUserStats(travelHistory)} />
        )}

        {/* Floating Widgets (Overlay) - Show when Focus tab is active */}
        {activeTab === 'Focus' && (
          <FloatingWidgets
            formattedTime={formattedTime}
            distanceRemaining={distanceRemaining}
            onPause={handlePause}
            onEndTrip={handleEndTrip}
            isActive={isActive}
            startLocation={startLocationName}
            setStartLocation={handleStartLocationChange}
            endLocation={endLocationName}
            setEndLocation={handleEndLocationChange}
            onStartTrip={handlePrepareTrip}
            hasStarted={hasStarted}
            focusMiles={focusMiles}
          />
        )}

        {/* Co-op Status Widget (On Map) */}
        {activeTab === 'Focus' && (
          <CoopStatusWidget coop={coop} />
        )}

        {/* Social Hub (Modal/Panel) */}
        {activeTab === 'Social' && (
          <SocialHub 
            userId={user.id} 
            onViewPassport={setViewingPassportId} 
            onClose={() => setActiveTab('Focus')}
            coop={coop}
            userLocation={startCoords}
          />
        )}

        {/* Passport Modal */}
        {viewingPassportId && (
          <PassportModal 
            targetUserId={viewingPassportId} 
            currentUserId={user.id} 
            onClose={() => setViewingPassportId(null)} 
          />
        )}

        {/* History Panel */}
        {activeTab === 'History' && <TravelHistoryPanel history={travelHistory} />}
        
        {/* Passport Panel */}
        {activeTab === 'Passport' && (
          <PassportPanel 
            ownedVisas={ownedVisas} 
            travelHistory={travelHistory} 
            passportData={passportData}
            onUpdatePassport={handleUpdatePassport}
          />
        )}

        {/* Market Panel */}
        {activeTab === 'Market' && (
          <MarketPanel 
            balance={focusMiles} 
            owned={ownedVisas} 
            onBuy={handleBuyVisa} 
          />
        )}

        {/* Account Panel */}
        {activeTab === 'Account' && (
          <AccountPanel 
            user={user} 
            onLogout={handleLogout} 
            sidebarPosition={sidebarPosition}
            onSidebarPositionChange={setSidebarPosition}
            language={language}
            onLanguageChange={setLanguage}
          />
        )}
        
        {/* Modals */}
        {showTransportModal && (
          <TransportModal 
            onSelect={handleSelectTransport} 
            onCancel={() => setShowTransportModal(false)} 
          />
        )}
        
        {showTicketModal && (
          <TicketModal
            startLocation={startLocationName}
            endLocation={endLocationName}
            distance={totalDistance}
            durationSeconds={totalDuration}
            onConfirm={startActualTrip}
            onCancel={() => setShowTicketModal(false)}
          />
        )}

        {visaAlert.show && (
          <VisaAlertModal
            cityName={visaAlert.cityName}
            visaName={visaAlert.visaName}
            onClose={() => setVisaAlert({ ...visaAlert, show: false })}
            onGoToMarket={() => {
              setVisaAlert({ ...visaAlert, show: false });
              setActiveTab('Market');
            }}
          />
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AudioProvider>
        <AppContent />
      </AudioProvider>
    </LanguageProvider>
  );
}
