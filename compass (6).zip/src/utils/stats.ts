import { TravelHistoryItem } from '../components/TravelHistoryPanel';

export interface UserStats {
  hoursWalked: number;
  hoursPlane: number;
  hoursCar: number;
  totalDistanceKm: number;
  countriesVisited: number;
}

export function calculateUserStats(history: TravelHistoryItem[]): UserStats {
  let minutesWalked = 0;
  let minutesPlane = 0;
  let minutesCar = 0;
  let totalDistanceKm = 0;
  const uniqueCountries = new Set<string>();

  history.forEach(trip => {
    if (trip.country) {
      uniqueCountries.add(trip.country.toLowerCase());
    }

    const durationMinutes = parseDuration(trip.duration);
    
    switch (trip.type) {
      case 'foot':
        minutesWalked += durationMinutes;
        totalDistanceKm += (durationMinutes / 60) * 5; // 5 km/h
        break;
      case 'car':
        minutesCar += durationMinutes;
        totalDistanceKm += (durationMinutes / 60) * 100; // 100 km/h
        break;
      case 'plane':
        minutesPlane += durationMinutes;
        totalDistanceKm += (durationMinutes / 60) * 900; // 900 km/h
        break;
    }
  });

  return {
    hoursWalked: Math.round(minutesWalked / 60 * 10) / 10,
    hoursPlane: Math.round(minutesPlane / 60 * 10) / 10,
    hoursCar: Math.round(minutesCar / 60 * 10) / 10,
    totalDistanceKm: Math.round(totalDistanceKm),
    countriesVisited: uniqueCountries.size
  };
}

function parseDuration(durationStr: string): number {
  let minutes = 0;
  
  // Handle "1h 30m" format
  const hoursMatch = durationStr.match(/(\d+)h/);
  if (hoursMatch) {
    minutes += parseInt(hoursMatch[1]) * 60;
  }
  
  const minutesMatch = durationStr.match(/(\d+)m/);
  if (minutesMatch) {
    minutes += parseInt(minutesMatch[1]);
  }
  
  return minutes;
}
