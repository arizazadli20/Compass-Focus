import { useState, useEffect, useCallback } from 'react';

export interface ParticipantLocation {
  username: string;
  lat: number;
  lng: number;
  progress: number;
}

export interface CoopState {
  socket: WebSocket | null;
  roomId: string | null;
  status: 'idle' | 'waiting' | 'active' | 'penalty';
  participants: string[];
  participantLocations: Record<string, ParticipantLocation>;
  penaltyUser: string | null;
  destination: string | null;
  transportMode: string | null;
  isHost: boolean;
  createRoom: (destination: string, transportMode: string) => void;
  joinRoom: (roomId: string) => void;
  updateRoom: (destination: string, transportMode: string) => void;
  removeRoom: () => void;
  startTrip: () => void;
  updateFocus: (isFocused: boolean) => void;
  updateLocation: (lat: number, lng: number, progress: number) => void;
}

export function useCoop(username: string, userId: number, onSpeedChange: (speed: number) => void) {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'waiting' | 'active' | 'penalty'>('idle');
  const [participants, setParticipants] = useState<string[]>([]);
  const [participantLocations, setParticipantLocations] = useState<Record<string, ParticipantLocation>>({});
  const [penaltyUser, setPenaltyUser] = useState<string | null>(null);
  const [destination, setDestination] = useState<string | null>(null);
  const [transportMode, setTransportMode] = useState<string | null>(null);
  const [isHost, setIsHost] = useState(false);

  useEffect(() => {
    if (!userId) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);
    
    ws.onopen = () => {
      console.log('Connected to Co-op Server');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'ROOM_CREATED':
            setRoomId(data.payload.roomId);
            setDestination(data.payload.destination);
            setTransportMode(data.payload.transportMode);
            setIsHost(data.payload.isHost);
            setStatus('waiting');
            setParticipants([username]);
            break;
          
          case 'ROOM_JOINED':
            setRoomId(data.payload.roomId);
            setDestination(data.payload.destination);
            setTransportMode(data.payload.transportMode);
            setStatus(data.payload.status);
            setParticipants(data.payload.participants || [username]);
            if (data.payload.participantLocations) {
              setParticipantLocations(data.payload.participantLocations);
            }
            setIsHost(data.payload.isHost);
            break;

          case 'PLAYER_JOINED':
            setParticipants(data.payload.participants || []);
            break;
            
          case 'ROOM_UPDATED':
            setDestination(data.payload.destination);
            setTransportMode(data.payload.transportMode);
            break;

          case 'ROOM_REMOVED':
            setRoomId(null);
            setStatus('idle');
            setParticipants([]);
            setDestination(null);
            setTransportMode(null);
            setIsHost(false);
            setParticipantLocations({});
            alert('Room has been removed by the host.');
            break;

          case 'LOCATION_UPDATED':
            setParticipantLocations(prev => ({
              ...prev,
              [data.payload.username]: {
                username: data.payload.username,
                lat: data.payload.lat,
                lng: data.payload.lng,
                progress: data.payload.progress
              }
            }));
            break;

          case 'TRIP_STARTED':
            setStatus('active');
            break;

          case 'PENALTY_TRIGGERED':
            setStatus('penalty');
            setPenaltyUser(data.payload.username);
            onSpeedChange(data.payload.speed);
            break;

          case 'PENALTY_CLEARED':
            setStatus('active');
            setPenaltyUser(null);
            onSpeedChange(data.payload.speed);
            break;
            
          case 'PLAYER_LEFT':
            setParticipants(prev => prev.filter(p => p !== data.payload.username));
            setParticipantLocations(prev => {
              const next = { ...prev };
              delete next[data.payload.username];
              return next;
            });
            break;
        }
      } catch (e) {
        console.error('WebSocket error:', e);
      }
    };

    setSocket(ws);

    return () => {
      ws.close();
    };
  }, [userId, username, onSpeedChange]);

  const createRoom = useCallback((destination: string, transportMode: string) => {
    if (socket) {
      socket.send(JSON.stringify({
        type: 'CREATE_ROOM',
        payload: { userId, username, destination, transportMode }
      }));
    }
  }, [socket, userId, username]);

  const joinRoom = useCallback((inputRoomId: string) => {
    if (socket) {
      socket.send(JSON.stringify({
        type: 'JOIN_ROOM',
        payload: { roomId: inputRoomId, userId, username }
      }));
    }
  }, [socket, userId, username]);

  const updateRoom = useCallback((destination: string, transportMode: string) => {
    if (socket) {
      socket.send(JSON.stringify({
        type: 'UPDATE_ROOM',
        payload: { destination, transportMode }
      }));
    }
  }, [socket]);

  const removeRoom = useCallback(() => {
    if (socket && roomId) {
      socket.send(JSON.stringify({
        type: 'REMOVE_ROOM',
        payload: { roomId, userId }
      }));
      // Reset local state immediately
      setRoomId(null);
      setStatus('idle');
      setParticipants([]);
      setDestination(null);
      setTransportMode(null);
      setIsHost(false);
      setParticipantLocations({});
    }
  }, [socket, roomId, userId]);

  const startTrip = useCallback(() => {
    if (socket) {
      socket.send(JSON.stringify({
        type: 'START_TRIP'
      }));
    }
  }, [socket]);

  const updateFocus = useCallback((isFocused: boolean) => {
    if (socket && status !== 'idle' && status !== 'waiting') {
      socket.send(JSON.stringify({
        type: 'UPDATE_FOCUS',
        payload: { focused: isFocused }
      }));
    }
  }, [socket, status]);

  const updateLocation = useCallback((lat: number, lng: number, progress: number) => {
    if (socket && status === 'active') {
      socket.send(JSON.stringify({
        type: 'UPDATE_LOCATION',
        payload: { lat, lng, progress }
      }));
    }
  }, [socket, status]);

  return {
    socket,
    roomId,
    status,
    participants,
    participantLocations,
    penaltyUser,
    destination,
    transportMode,
    isHost,
    createRoom,
    joinRoom,
    updateRoom,
    removeRoom,
    startTrip,
    updateFocus,
    updateLocation
  };
}
