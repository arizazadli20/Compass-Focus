import { useState, useEffect } from 'react';

export interface Coordinates {
  lat: number;
  lng: number;
}

export function useFlightTimer(
  startCoords: Coordinates,
  endCoords: Coordinates,
  totalDurationSeconds: number,
  totalDistanceKm: number,
  isActive: boolean,
  speedMultiplier: number = 1.0
) {
  const [timeRemaining, setTimeRemaining] = useState(totalDurationSeconds);
  const [currentCoords, setCurrentCoords] = useState<Coordinates>(startCoords);

  useEffect(() => {
    setTimeRemaining(totalDurationSeconds);
    setCurrentCoords(startCoords);
  }, [startCoords, endCoords, totalDurationSeconds]);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining((prev) => {
          // Decrement by speedMultiplier (e.g., 1.0 for normal, 0.5 for slow)
          // If speed is 0.5, we subtract 0.5 seconds "worth" of progress every second?
          // No, timeRemaining is in seconds. If speed is 0.5x, it takes 2 real seconds to cover 1 "flight second".
          // So we should subtract speedMultiplier from timeRemaining?
          // If totalDuration is 100s. Speed 1.0 -> 100s real time.
          // Speed 0.5 -> We cover 0.5s of "flight time" per real second. So it takes 200s real time.
          // Yes, subtract speedMultiplier.
          
          const newTime = Math.max(0, prev - speedMultiplier);
          
          // Calculate progress (0 to 1)
          // We need original totalDurationSeconds to be constant reference
          const progress = 1 - (newTime / totalDurationSeconds);
          
          // Interpolate coordinates (simple linear interpolation for now)
          const newLat = startCoords.lat + (endCoords.lat - startCoords.lat) * progress;
          const newLng = startCoords.lng + (endCoords.lng - startCoords.lng) * progress;
          
          setCurrentCoords({ lat: newLat, lng: newLng });
          
          return newTime;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive, timeRemaining, startCoords, endCoords, totalDurationSeconds, speedMultiplier]);

  const distanceRemaining = (timeRemaining / totalDurationSeconds) * totalDistanceKm;

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(seconds % 60).toString().padStart(2, '0');
    if (h > 0) {
      return `${h}:${m}:${s}`;
    }
    return `${m}:${s}`;
  };

  return {
    timeRemaining,
    formattedTime: formatTime(timeRemaining),
    distanceRemaining: distanceRemaining.toFixed(1),
    currentCoords,
    progress: 1 - (timeRemaining / totalDurationSeconds)
  };
}
